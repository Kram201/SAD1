from werkzeug.security import generate_password_hash

# Generate a password hash for 'admin123'
password = 'admin123'
hashed_password = generate_password_hash(password)
print(f"Password: {password}")
print(f"Hashed Password: {hashed_password}")
print("\nSQL Command to update admin password:")
print(f"UPDATE users SET password = '{hashed_password}' WHERE email = 'admin@example.com';")
