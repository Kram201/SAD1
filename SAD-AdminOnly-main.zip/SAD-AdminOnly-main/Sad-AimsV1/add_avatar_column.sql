-- Add avatar_path column to users table
ALTER TABLE users ADD COLUMN avatar_path VARCHAR(255) DEFAULT NULL;
