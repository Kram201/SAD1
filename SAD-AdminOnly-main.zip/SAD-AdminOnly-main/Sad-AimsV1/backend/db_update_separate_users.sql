-- SQL script to separate admin and customer users
-- Run this to update the existing database structure

USE aircon_inventory_db;

-- First create a new admins table (already have customers table)
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    address VARCHAR(255),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Transfer all admin users from users table to admins table
INSERT INTO admins (name, email, password, address, phone, created_at, updated_at)
SELECT name, email, password, address, phone, created_at, updated_at
FROM users;

-- After confirming everything works, you can remove the old users table:
-- DROP TABLE users;
