from flask import Blueprint, render_template, request, redirect, url_for, flash, session
import pymysql
import os
import sys
from datetime import datetime

# Add parent directory to path to make imports work
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import get_db_connection

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if not email or not password:
            flash('Email and password are required', 'error')
            return render_template('auth/login.html')
        
        conn = get_db_connection()
        try:
            with conn.cursor() as cursor:
                # Check for admin user in users table (temporary until migration is complete)
                cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
                user = cursor.fetchone()
                
                if user and user['password'] == password:
                    session['user_id'] = user['id']
                    session['name'] = user['name']
                    session['email'] = user['email']
                    session['role'] = 'admin'
                    # Add avatar path to session if it exists
                    if user.get('avatar_path'):
                        session['avatar'] = user['avatar_path']
                    return redirect(url_for('admin.dashboard'))
                
                # Check for customer user
                cursor.execute("SELECT * FROM customers WHERE email = %s", (email,))
                user = cursor.fetchone()
                
                if user and user['password'] == password:
                    session['user_id'] = user['id']
                    session['name'] = user['name']
                    session['email'] = user['email']
                    session['role'] = 'customer'
                    # Add avatar path to session if it exists
                    if user.get('avatar_path'):
                        session['avatar'] = user['avatar_path']
                    return redirect(url_for('customer.dashboard'))
                
                flash('Invalid email or password', 'error')
                return render_template('auth/login.html')
        except Exception as e:
            flash(f'Login error: {str(e)}', 'error')
            return render_template('auth/login.html', error=str(e))
        finally:
            conn.close()
    
    return render_template('auth/login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        address = request.form.get('address', '')
        phone = request.form.get('phone', '')
        
        if not name or not email or not password:
            flash('Name, email, and password are required', 'error')
            return render_template('auth/register.html')
            
        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return render_template('auth/register.html')
        
        conn = get_db_connection()
        try:
            with conn.cursor() as cursor:
                # Check if email already exists
                cursor.execute("SELECT * FROM customers WHERE email = %s", (email,))
                if cursor.fetchone():
                    flash('Email already exists', 'error')
                    return render_template('auth/register.html')
                
                # Insert new customer
                cursor.execute(
                    "INSERT INTO customers (name, email, password, address, phone) VALUES (%s, %s, %s, %s, %s)",
                    (name, email, password, address, phone)
                )
            conn.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('auth.login'))
        except Exception as e:
            conn.rollback()
            flash(f'Registration error: {str(e)}', 'error')
            return render_template('auth/register.html', error=str(e))
        finally:
            conn.close()
    
    return render_template('auth/register.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    role = session.get('role')
    
    conn = get_db_connection()
    try:
        if request.method == 'POST':
            name = request.form.get('name')
            email = request.form.get('email')
            address = request.form.get('address', '')
            phone = request.form.get('phone', '')
            current_password = request.form.get('current_password')
            new_password = request.form.get('new_password')
            
            # Determine which table to update based on role
            table = 'users' if role == 'admin' else 'customers'
            
            with conn.cursor() as cursor:
                # If changing password, validate current password
                if current_password and new_password:
                    cursor.execute(f"SELECT password FROM {table} WHERE id = %s", (user_id,))
                    user = cursor.fetchone()
                    
                    if not user['password'] == current_password:
                        flash('Current password is incorrect', 'error')
                        return redirect(url_for('auth.profile'))
                    
                    cursor.execute(f"UPDATE {table} SET password = %s WHERE id = %s", (new_password, user_id))
                
                # Update other profile information
                cursor.execute(
                    f"UPDATE {table} SET name = %s, email = %s, address = %s, phone = %s WHERE id = %s",
                    (name, email, address, phone, user_id)
                )
                
                # Update session data
                session['name'] = name
                session['email'] = email
                
            conn.commit()
            flash('Profile updated successfully', 'success')
            
        # Get current user data
        with conn.cursor() as cursor:
            table = 'users' if role == 'admin' else 'customers'
            cursor.execute(f"SELECT * FROM {table} WHERE id = %s", (user_id,))
            user = cursor.fetchone()
            
        if not user:
            session.clear()
            flash('User not found', 'error')
            return redirect(url_for('auth.login'))
            
        return render_template('auth/profile.html', user=user)
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('auth.login'))
    finally:
        conn.close()