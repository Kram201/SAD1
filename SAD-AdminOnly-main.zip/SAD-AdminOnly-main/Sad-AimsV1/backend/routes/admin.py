from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session, make_response
from werkzeug.utils import secure_filename
from functools import wraps
import pymysql
import os
import sys
import io
import csv
from datetime import datetime

# Add parent directory to path to make imports work
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import get_db_connection

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# Auth middleware for admin access
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'admin':
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

# Helper functions
def allowed_file(filename, allowed_extensions):
    """
    Check if the file has an allowed extension
    """
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

# Route handling functions
@admin_bp.route('/dashboard')
@admin_required  # Only admins can access dashboard
def dashboard():
    conn = get_db_connection()
    try:
        # Get inventory stats
        with conn.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) as total_products FROM products")
            product_count = cursor.fetchone()
            
        # Get low stock items
        with conn.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) as low_stock_count FROM products WHERE quantity <= min_quantity AND quantity > 0")
            low_stock_count = cursor.fetchone()
        
        # Get out of stock items
        with conn.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) as out_of_stock_count FROM products WHERE quantity = 0")
            out_of_stock_count = cursor.fetchone()
            
        # Get total categories
        with conn.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) as total_categories FROM categories")
            category_count = cursor.fetchone()
            
        # Get total orders
        with conn.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) as total_orders FROM orders")
            order_count = cursor.fetchone()
            
        # Get pending orders
        with conn.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) as pending_orders FROM orders WHERE status = 'pending'")
            pending_order_count = cursor.fetchone()
        
        # Get recent orders for the table display
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM orders ORDER BY created_at DESC LIMIT 5")
            recent_orders = cursor.fetchall()
            
        # Add pagination variables for template consistency
        total_pages = 1
        current_page = 1
        
        return render_template('admin/dashboard.html', 
                             product_count=product_count['total_products'],
                             low_stock_count=low_stock_count['low_stock_count'],
                             out_of_stock_count=out_of_stock_count['out_of_stock_count'],
                             category_count=category_count['total_categories'],
                             order_count=order_count['total_orders'],
                             pending_order_count=pending_order_count['pending_orders'],
                             recent_orders=recent_orders,
                             total_pages=total_pages,
                             current_page=current_page)
    except Exception as e:
        print(f"Error in dashboard: {e}")
        return render_template('admin/dashboard.html', error=str(e))
    finally:
        conn.close()

@admin_bp.route('/inventory')
@admin_required  # Only admins can view inventory
def inventory():
    conn = get_db_connection()
    try:
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = 20  # Show more items per page for inventory
        offset = (page - 1) * per_page

        # Get search and filter parameters
        search_query = request.args.get('search', '')
        selected_category = request.args.get('category', '')
        
        # Base query
        query = """
            SELECT p.*, c.name as category_name 
            FROM products p
            JOIN categories c ON p.category_id = c.id
            WHERE 1=1
        """
        params = []
        
        # Add search condition if provided
        if search_query:
            query += " AND (p.name LIKE %s OR p.description LIKE %s)"
            params.extend([f'%{search_query}%', f'%{search_query}%'])
        
        # Add category filter if provided
        if selected_category:
            query += " AND p.category_id = %s"
            params.append(selected_category)
        
        # Count total products matching criteria
        count_query = f"SELECT COUNT(*) as total FROM ({query}) as filtered_products"
        
        with conn.cursor() as cursor:
            cursor.execute(count_query, params)
            total_products = cursor.fetchone()['total']
        
        # Add pagination
        query += " ORDER BY p.name LIMIT %s OFFSET %s"
        params.extend([per_page, offset])
        
        # Get products
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            products = cursor.fetchall()
            
        # Get all categories
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM categories")
            categories = cursor.fetchall()
        
        # Calculate pagination info
        total_pages = (total_products + per_page - 1) // per_page
            
        return render_template('admin/inventory/index.html', 
                              products=products,
                              categories=categories,
                              current_page=page,
                              total_pages=total_pages,
                              search_query=search_query,
                              selected_category=selected_category)
    except Exception as e:
        print(f"Error in inventory: {e}")
        return render_template('admin/inventory/index.html', error=str(e))
    finally:
        conn.close()

@admin_bp.route('/products')
@admin_required  # Only admins can view products
def products_list():
    conn = get_db_connection()
    try:
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = 10
        offset = (page - 1) * per_page
        
        # Get search and filter parameters
        search_query = request.args.get('search', '')
        selected_category = request.args.get('category', '')
        
        # Base query
        query = """
            SELECT p.*, c.name as category_name 
            FROM products p
            JOIN categories c ON p.category_id = c.id
            WHERE 1=1
        """
        params = []
        
        # Add search condition if provided
        if search_query:
            query += " AND (p.name LIKE %s OR p.description LIKE %s)"
            params.extend([f'%{search_query}%', f'%{search_query}%'])
        
        # Add category filter if provided
        if selected_category:
            query += " AND p.category_id = %s"
            params.append(selected_category)
        
        # Count total products matching criteria
        count_query = f"SELECT COUNT(*) as total FROM ({query}) as filtered_products"
        
        with conn.cursor() as cursor:
            cursor.execute(count_query, params)
            total_products = cursor.fetchone()['total']
        
        # Add pagination
        query += " ORDER BY p.name LIMIT %s OFFSET %s"
        params.extend([per_page, offset])
        
        # Get products
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            products = cursor.fetchall()
        
        # Get all categories for filter dropdown
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM categories")
            categories = cursor.fetchall()
        
        # Calculate pagination info
        total_pages = (total_products + per_page - 1) // per_page
        
        return render_template('admin/products/index.html', 
                              products=products,
                              categories=categories,
                              current_page=page,
                              total_pages=total_pages,
                              search_query=search_query,
                              selected_category=selected_category)
    except Exception as e:
        print(f"Error in products listing: {e}")
        flash(f"Error: {str(e)}", "error")
        
        # Add required pagination variables for the error case
        total_pages = 1
        current_page = 1
        
        return render_template('admin/products/index.html', 
                              error=str(e),
                              products=[],
                              categories=[],
                              total_pages=total_pages,
                              current_page=current_page,
                              search_query='',
                              selected_category='')
    finally:
        conn.close()

@admin_bp.route('/products/add', methods=['GET', 'POST'])
@admin_required  # Only admins can add products
def add_product():
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        category_id = request.form.get('category_id')
        quantity = request.form.get('quantity')
        min_quantity = request.form.get('min_quantity')
        entry_price = request.form.get('entry_price')
        price = request.form.get('price')
        
        # Handle image upload
        image_path = None
        if 'image' in request.files:
            image = request.files['image']
            if image.filename:
                filename = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{image.filename}"
                image_path = os.path.join('static/uploads/products', filename)
                os.makedirs(os.path.dirname(image_path), exist_ok=True)
                image.save(image_path)
        
        conn = get_db_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO products (name, description, category_id, quantity, min_quantity, entry_price, price, image_path)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """, (name, description, category_id, quantity, min_quantity, entry_price, price, image_path))
            conn.commit()
            flash('Product added successfully', 'success')
            return redirect(url_for('admin.inventory'))
        except Exception as e:
            conn.rollback()
            flash(f'Error adding product: {str(e)}', 'error')
            return redirect(url_for('admin.add_product'))
        finally:
            conn.close()
    
    # GET request - show the form
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM categories")
            categories = cursor.fetchall()
        return render_template('admin/products/add.html', categories=categories)
    except Exception as e:
        flash(f'Error loading categories: {str(e)}', 'error')
        return render_template('admin/products/add.html', categories=[])
    finally:
        conn.close()

@admin_bp.route('/products/edit/<int:product_id>', methods=['GET', 'POST'])
@admin_required  # Only admins can edit products
def edit_product(product_id):
    conn = get_db_connection()
    
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        category_id = request.form.get('category_id')
        quantity = request.form.get('quantity')
        min_quantity = request.form.get('min_quantity')
        entry_price = request.form.get('entry_price')
        price = request.form.get('price')
        
        # Handle image upload
        image_path = request.form.get('existing_image')
        if 'image' in request.files:
            image = request.files['image']
            if image.filename:
                filename = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{image.filename}"
                image_path = os.path.join('static/uploads/products', filename)
                os.makedirs(os.path.dirname(image_path), exist_ok=True)
                image.save(image_path)
        
        try:
            with conn.cursor() as cursor:
                cursor.execute("""
                    UPDATE products 
                    SET name=%s, description=%s, category_id=%s, quantity=%s, 
                        min_quantity=%s, entry_price=%s, price=%s, image_path=%s
                    WHERE id=%s
                """, (name, description, category_id, quantity, min_quantity, 
                      entry_price, price, image_path, product_id))
            conn.commit()
            flash('Product updated successfully', 'success')
            return redirect(url_for('admin.inventory'))
        except Exception as e:
            conn.rollback()
            flash(f'Error updating product: {str(e)}', 'error')
            return redirect(url_for('admin.edit_product', product_id=product_id))
        finally:
            conn.close()
    
    # GET request - load the form with existing data
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM products WHERE id=%s", (product_id,))
            product = cursor.fetchone()
            
            if not product:
                flash('Product not found', 'error')
                return redirect(url_for('admin.inventory'))
            
            cursor.execute("SELECT * FROM categories")
            categories = cursor.fetchall()
            
        return render_template('admin/products/edit.html', 
                              product=product,
                              categories=categories)
    except Exception as e:
        flash(f'Error loading product data: {str(e)}', 'error')
        return redirect(url_for('admin.inventory'))
    finally:
        conn.close()

@admin_bp.route('/products/delete/<int:product_id>', methods=['POST'])
@admin_required
def delete_product(product_id):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM products WHERE id=%s", (product_id,))
        conn.commit()
        flash('Product deleted successfully', 'success')
    except Exception as e:
        conn.rollback()
        flash(f'Error deleting product: {str(e)}', 'error')
    finally:
        conn.close()
    return redirect(url_for('admin.inventory'))

@admin_bp.route('/orders')
@admin_required  # Only admins can view orders
def orders():
    conn = get_db_connection()
    try:
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = 10
        offset = (page - 1) * per_page
        
        # Get search and filter parameters
        search_query = request.args.get('search', '')
        status_filter = request.args.get('status', '')
        
        # Base query
        query = """
            SELECT o.*, c.name as customer_name, c.email as customer_email
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            WHERE 1=1
        """
        params = []
        
        # Add search condition if provided
        if search_query:
            query += " AND (c.name LIKE %s OR c.email LIKE %s OR o.order_number LIKE %s)"
            params.extend([f'%{search_query}%', f'%{search_query}%', f'%{search_query}%'])
        
        # Add status filter if provided
        if status_filter:
            query += " AND o.status = %s"
            params.append(status_filter)
        
        # Count total orders matching criteria
        count_query = f"SELECT COUNT(*) as total FROM ({query}) as filtered_orders"
        
        with conn.cursor() as cursor:
            cursor.execute(count_query, params)
            total_orders = cursor.fetchone()['total']
        
        # Add pagination
        query += " ORDER BY o.created_at DESC LIMIT %s OFFSET %s"
        params.extend([per_page, offset])
        
        # Get orders
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            orders = cursor.fetchall()
            
            # Get order items for each order
            for order in orders:
                cursor.execute("""
                    SELECT oi.*, p.name as product_name, p.image_path
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.id
                    WHERE oi.order_id = %s
                """, (order['id'],))
                order['items'] = cursor.fetchall()
                
                # Calculate order summary
                order['total_items'] = sum(item['quantity'] for item in order['items'])
        
        # Get all possible order statuses for filter dropdown
        statuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'completed']
        
        # Calculate pagination info
        total_pages = (total_orders + per_page - 1) // per_page
        
        return render_template('admin/orders/index.html', 
                              orders=orders,
                              statuses=statuses,
                              current_page=page,
                              total_pages=total_pages,
                              search_query=search_query,
                              status_filter=status_filter)
    except Exception as e:
        print(f"Error in orders listing: {e}")
        flash(f"Error: {str(e)}", "error")
        return render_template('admin/orders/index.html', error=str(e))
    finally:
        conn.close()

@admin_bp.route('/orders/pending')
@admin_required
def pending_orders():
    conn = get_db_connection()
    try:
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = 10
        offset = (page - 1) * per_page
        
        # Get search and filter parameters
        search_query = request.args.get('search', '')
        status_filter = request.args.get('status', '')
        
        # Base query for pending orders only
        query = """
            SELECT o.*, c.name as customer_name, c.email as customer_email
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            WHERE o.status = 'pending'
        """
        params = []
        
        # Add search condition if provided
        if search_query:
            query += " AND (c.name LIKE %s OR c.email LIKE %s OR o.order_number LIKE %s)"
            params.extend([f'%{search_query}%', f'%{search_query}%', f'%{search_query}%'])
        
        # Count total pending orders matching criteria
        count_query = f"SELECT COUNT(*) as total FROM ({query}) as filtered_orders"
        
        with conn.cursor() as cursor:
            cursor.execute(count_query, params)
            total_orders = cursor.fetchone()['total']
        
        # Add pagination
        query += " ORDER BY o.created_at DESC LIMIT %s OFFSET %s"
        params.extend([per_page, offset])
        
        # Get orders
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            orders = cursor.fetchall()
            
            # Get order items for each order
            for order in orders:
                cursor.execute("""
                    SELECT oi.*, p.name as product_name, p.image_path
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.id
                    WHERE oi.order_id = %s
                """, (order['id'],))
                order['items'] = cursor.fetchall()
                
                # Calculate order summary
                order['total_items'] = sum(item['quantity'] for item in order['items'])
        
        # Calculate pagination info
        total_pages = (total_orders + per_page - 1) // per_page
        
        return render_template('admin/orders/pending.html', 
                              orders=orders,
                              current_page=page,
                              total_pages=total_pages,
                              search_query=search_query,
                              title="Pending Orders")
    except Exception as e:
        print(f"Error in pending orders listing: {e}")
        flash(f"Error: {str(e)}", "error")
        return render_template('admin/orders/pending.html', error=str(e), title="Pending Orders")
    finally:
        conn.close()

@admin_bp.route('/orders/completed')
@admin_required
def completed_orders():
    conn = get_db_connection()
    try:
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = 10
        offset = (page - 1) * per_page
        
        # Base query for completed orders only
        query = """
            SELECT o.*, c.name as customer_name, c.email as customer_email
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            WHERE o.status = 'completed'
        """
        params = []
        
        # Add search condition if provided
        search_query = request.args.get('search', '')
        if search_query:
            query += " AND (c.name LIKE %s OR c.email LIKE %s OR o.order_number LIKE %s)"
            params.extend([f'%{search_query}%', f'%{search_query}%', f'%{search_query}%'])
        
        # Count total completed orders matching criteria
        count_query = f"SELECT COUNT(*) as total FROM ({query}) as filtered_orders"
        
        with conn.cursor() as cursor:
            cursor.execute(count_query, params)
            total_orders = cursor.fetchone()['total']
        
        # Add pagination
        query += " ORDER BY o.created_at DESC LIMIT %s OFFSET %s"
        params.extend([per_page, offset])
        
        # Get orders
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            orders = cursor.fetchall()
            
            # Get order items for each order
            for order in orders:
                cursor.execute("""
                    SELECT oi.*, p.name as product_name, p.image_path
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.id
                    WHERE oi.order_id = %s
                """, (order['id'],))
                order['items'] = cursor.fetchall()
                
                # Calculate order summary
                order['total_items'] = sum(item['quantity'] for item in order['items'])
        
        # Calculate pagination info
        total_pages = (total_orders + per_page - 1) // per_page
        
        return render_template('admin/orders/completed.html', 
                              orders=orders,
                              current_page=page,
                              total_pages=total_pages,
                              search_query=search_query,
                              title="Completed Orders")
    except Exception as e:
        print(f"Error in completed orders listing: {e}")
        flash(f"Error: {str(e)}", "error")
        return render_template('admin/orders/completed.html', error=str(e), title="Completed Orders")
    finally:
        conn.close()

@admin_bp.route('/reports')
@admin_required  # Only admins can view reports
def reports():
    return render_template('admin/reports/index.html')

@admin_bp.route('/reports/sales', methods=['GET', 'POST'])
@admin_required
def sales_report():
    start_date = request.form.get('start_date', datetime.now().strftime('%Y-%m-01'))
    end_date = request.form.get('end_date', datetime.now().strftime('%Y-%m-%d'))
    
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT o.*, c.name as customer_name
                FROM orders o
                JOIN customers c ON o.customer_id = c.id
                WHERE o.created_at BETWEEN %s AND %s
                ORDER BY o.created_at DESC
            """, (start_date, end_date))
            orders = cursor.fetchall()
            
        # Calculate totals
        total_sales = sum(order['total_amount'] for order in orders)
        order_count = len(orders)
        
        return render_template('admin/reports/sales.html',
                              orders=orders,
                              total_sales=total_sales,
                              order_count=order_count,
                              start_date=start_date,
                              end_date=end_date)
    except Exception as e:
        flash(f'Error generating report: {str(e)}', 'error')
        return render_template('admin/reports/sales.html', 
                              orders=[],
                              error=str(e))
    finally:
        conn.close()

@admin_bp.route('/reports/inventory')
@admin_required
def inventory_report():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT p.*, c.name as category_name
                FROM products p
                JOIN categories c ON p.category_id = c.id
                ORDER BY p.quantity
            """)
            products = cursor.fetchall()
            
        # Get categories for filter
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM categories ORDER BY name")
            categories = cursor.fetchall()
            
        # Calculate inventory summary
        total_value = sum(product['entry_price'] * product['quantity'] for product in products)
        low_stock_count = sum(1 for product in products if 0 < product['quantity'] <= product['min_quantity'])
        out_of_stock_count = sum(1 for product in products if product['quantity'] <= 0)
        
        # Create inventory summary object
        inventory_summary = {
            'total_products': len(products),
            'low_stock': low_stock_count,
            'out_of_stock': out_of_stock_count,
            'total_value': total_value
        }
        
        # Add pagination variables
        total_pages = 1
        current_page = 1
        selected_category = ""
        stock_status = ""
        
        return render_template('admin/reports/inventory.html',
                              products=products,
                              categories=categories,
                              inventory_summary=inventory_summary,
                              total_pages=total_pages,
                              current_page=current_page,
                              selected_category=selected_category,
                              stock_status=stock_status)
    except Exception as e:
        flash(f'Error generating report: {str(e)}', 'error')
        
        # Create empty inventory summary for error case
        inventory_summary = {
            'total_products': 0,
            'low_stock': 0,
            'out_of_stock': 0,
            'total_value': 0
        }
        
        # Add pagination and other required variables
        total_pages = 1
        current_page = 1
        
        return render_template('admin/reports/inventory.html', 
                              products=[],
                              categories=[],
                              inventory_summary=inventory_summary,
                              total_pages=total_pages,
                              current_page=current_page,
                              selected_category='',
                              stock_status='',
                              error=str(e))
    finally:
        conn.close()

@admin_bp.route('/reports/inventory/export/pdf')
@admin_required
def export_inventory_pdf():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT p.*, c.name as category_name
                FROM products p
                JOIN categories c ON p.category_id = c.id
                ORDER BY p.name
            """)
            products = cursor.fetchall()
        
        # Set headers for HTML download instead of PDF
        current_time = datetime.now()
        response = make_response(render_template('admin/reports/inventory_pdf.html', 
                                               products=products,
                                               current_time=current_time))
        response.headers['Content-Disposition'] = 'attachment; filename=inventory_report.html'
        response.headers['Content-Type'] = 'text/html'
        return response
    except Exception as e:
        flash(f'Error generating PDF: {str(e)}', 'error')
        return redirect(url_for('admin.inventory_report'))
    finally:
        conn.close()

@admin_bp.route('/reports/inventory/export/excel')
@admin_required
def export_inventory_excel():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT p.id, p.name, c.name as category, p.description, p.quantity, 
                       p.min_quantity, p.entry_price, p.price
                FROM products p
                JOIN categories c ON p.category_id = c.id
                ORDER BY p.name
            """)
            products = cursor.fetchall()
        
        # Set headers for CSV download (simpler alternative to Excel)
        response = make_response('')
        response.headers['Content-Disposition'] = 'attachment; filename=inventory_report.csv'
        response.headers['Content-Type'] = 'text/csv'
        
        # Create CSV content
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header row
        writer.writerow(['ID', 'Product Name', 'Category', 'Description', 'Quantity', 
                       'Min Quantity', 'Cost Price', 'Selling Price', 'Value'])
        
        # Write data rows
        for product in products:
            writer.writerow([
                product['id'],
                product['name'],
                product['category'],
                product['description'],
                product['quantity'],
                product['min_quantity'],
                product['entry_price'],
                product['price'],
                product['quantity'] * product['entry_price']
            ])
        
        response.data = output.getvalue()
        return response
    except Exception as e:
        flash(f'Error generating Excel: {str(e)}', 'error')
        return redirect(url_for('admin.inventory_report'))
    finally:
        conn.close()

@admin_bp.route('/reports/sales/export/pdf')
@admin_required
def export_sales_pdf():
    # Get date range parameters
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    conn = get_db_connection()
    try:
        query = """
            SELECT o.*, c.name as customer_name, c.email as customer_email
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            WHERE 1=1
        """
        params = []
        
        if start_date and end_date:
            query += " AND o.created_at BETWEEN %s AND %s"
            params.extend([start_date, end_date])
            
        query += " ORDER BY o.created_at DESC"
        
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            orders = cursor.fetchall()
            
            # Get order items
            for order in orders:
                cursor.execute("""
                    SELECT oi.*, p.name as product_name
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.id
                    WHERE oi.order_id = %s
                """, (order['id'],))
                order['items'] = cursor.fetchall()
        
        # Set headers for HTML download instead of PDF
        current_time = datetime.now()
        response = make_response(render_template('admin/reports/sales_pdf.html', 
                                              orders=orders,
                                              start_date=start_date,
                                              end_date=end_date,
                                              current_time=current_time))
        response.headers['Content-Disposition'] = 'attachment; filename=sales_report.html'
        response.headers['Content-Type'] = 'text/html'
        return response
    except Exception as e:
        flash(f'Error generating PDF: {str(e)}', 'error')
        return redirect(url_for('admin.sales_report'))
    finally:
        conn.close()

@admin_bp.route('/reports/sales/export/excel')
@admin_required
def export_sales_excel():
    # Get date range parameters
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    conn = get_db_connection()
    try:
        query = """
            SELECT o.id, o.order_number, c.name as customer_name, o.created_at, 
                   o.total_amount, o.status
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            WHERE 1=1
        """
        params = []
        
        if start_date and end_date:
            query += " AND o.created_at BETWEEN %s AND %s"
            params.extend([start_date, end_date])
            
        query += " ORDER BY o.created_at DESC"
        
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            orders = cursor.fetchall()
        
        # Set headers for CSV download
        response = make_response('')
        response.headers['Content-Disposition'] = 'attachment; filename=sales_report.csv'
        response.headers['Content-Type'] = 'text/csv'
        
        # Create CSV content
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header row
        writer.writerow(['Order ID', 'Order Number', 'Customer', 'Date', 'Amount', 'Status'])
        
        # Write data rows
        for order in orders:
            writer.writerow([
                order['id'],
                order['order_number'],
                order['customer_name'],
                order['created_at'].strftime('%Y-%m-%d %H:%M:%S') if isinstance(order['created_at'], datetime) else order['created_at'],
                order['total_amount'],
                order['status']
            ])
        
        response.data = output.getvalue()
        return response
    except Exception as e:
        flash(f'Error generating Excel: {str(e)}', 'error')
        return redirect(url_for('admin.sales_report'))
    finally:
        conn.close()

@admin_bp.route('/categories', methods=['GET', 'POST'])
@admin_required
def categories():
    conn = get_db_connection()
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'add':
            name = request.form.get('name')
            description = request.form.get('description', '')
            
            try:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "INSERT INTO categories (name, description) VALUES (%s, %s)",
                        (name, description)
                    )
                conn.commit()
                flash('Category added successfully', 'success')
            except Exception as e:
                conn.rollback()
                flash(f'Error adding category: {str(e)}', 'error')
        
        elif action == 'edit':
            category_id = request.form.get('category_id')
            name = request.form.get('name')
            description = request.form.get('description', '')
            
            try:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "UPDATE categories SET name=%s, description=%s WHERE id=%s",
                        (name, description, category_id)
                    )
                conn.commit()
                flash('Category updated successfully', 'success')
            except Exception as e:
                conn.rollback()
                flash(f'Error updating category: {str(e)}', 'error')
        
        elif action == 'delete':
            category_id = request.form.get('category_id')
            
            try:
                with conn.cursor() as cursor:
                    # Check if category has products
                    cursor.execute("SELECT COUNT(*) as count FROM products WHERE category_id=%s", (category_id,))
                    result = cursor.fetchone()
                    
                    if result['count'] > 0:
                        flash('Cannot delete category with associated products', 'error')
                    else:
                        cursor.execute("DELETE FROM categories WHERE id=%s", (category_id,))
                        conn.commit()
                        flash('Category deleted successfully', 'success')
            except Exception as e:
                conn.rollback()
                flash(f'Error deleting category: {str(e)}', 'error')
    
    # Get all categories with product counts
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT c.*, COUNT(p.id) as product_count 
                FROM categories c
                LEFT JOIN products p ON c.id = p.category_id
                GROUP BY c.id
                ORDER BY c.name
            """)
            categories = cursor.fetchall()
        
        return render_template('admin/categories/index.html', categories=categories)
    except Exception as e:
        flash(f'Error loading categories: {str(e)}', 'error')
        return render_template('admin/categories/index.html', categories=[], error=str(e))
    finally:
        conn.close()

@admin_bp.route('/settings', methods=['GET', 'POST'])
@admin_required  # Only admins can access settings
def settings():
    conn = get_db_connection()
    try:
        # Get system settings
        with conn.cursor() as cursor:
            # Check if settings table exists
            cursor.execute("SHOW TABLES LIKE 'settings'")
            if not cursor.fetchone():
                # If settings table doesn't exist, create it
                cursor.execute("""
                    CREATE TABLE settings (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        setting_key VARCHAR(255) UNIQUE NOT NULL,
                        setting_value TEXT NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                    )
                """)
                
                # Insert default settings
                cursor.execute("""
                    INSERT INTO settings (setting_key, setting_value) VALUES
                    ('company_name', 'Aircon Inventory System'),
                    ('company_address', '123 Cooling Street, Airville'),
                    ('company_phone', '+1-234-567-8901'),
                    ('company_email', 'info@airconinventory.com'),
                    ('tax_rate', '0'),
                    ('currency', 'USD'),
                    ('items_per_page', '10'),
                    ('low_stock_threshold', '5'),
                    ('site_title', 'Aircon Inventory System'),
                    ('site_description', 'Manage your aircon inventory with ease'),
                    ('contact_email', 'info@airconinventory.com'),
                    ('contact_phone', '+1-234-567-8901'),
                    ('address', '123 Cooling Street, Airville'),
                    ('facebook_url', ''),
                    ('instagram_url', ''),
                    ('smtp_host', ''),
                    ('smtp_port', '587'),
                    ('smtp_user', ''),
                    ('smtp_password', ''),
                    ('smtp_ssl', '0'),
                    ('payment_methods', 'cod,bank_transfer')
                """)
                conn.commit()
            
            # Get all settings
            cursor.execute("SELECT * FROM settings")
            all_settings = cursor.fetchall()
            
            # Convert to dictionary for easier access in template
            settings_dict = {item['setting_key']: item['setting_value'] for item in all_settings}
            
            # Add default values for missing settings to prevent template errors
            default_settings = {
                'site_title': 'Aircon Inventory System',
                'site_description': 'Manage your aircon inventory with ease',
                'contact_email': 'info@airconinventory.com',
                'contact_phone': '+1-234-567-8901',
                'address': '123 Cooling Street, Airville',
                'facebook_url': '',
                'instagram_url': '',
                'smtp_host': '',
                'smtp_port': '587',
                'smtp_user': '',
                'smtp_password': '',
                'smtp_ssl': '0',
                'payment_methods': 'cod,bank_transfer',
                'currency': 'USD',
                'tax_rate': '0'
            }
            
            # Set default values for any missing keys
            for key, value in default_settings.items():
                if key not in settings_dict:
                    settings_dict[key] = value
                    
            # Process lists (like payment_methods) that should be converted from comma-separated strings
            if 'payment_methods' in settings_dict and settings_dict['payment_methods']:
                settings_dict['payment_methods'] = settings_dict['payment_methods'].split(',')
            else:
                settings_dict['payment_methods'] = []
            
        if request.method == 'POST':
            try:
                # Process form data
                form_data = request.form.to_dict(flat=False)
                
                # Create a new cursor for all update operations
                with conn.cursor() as update_cursor:
                    # Handle special cases like payment_methods which come as arrays
                    if 'payment_methods[]' in form_data:
                        payment_methods = form_data.get('payment_methods[]', [])
                        payment_methods_str = ','.join(payment_methods) if payment_methods else ''
                        
                        # Update payment_methods in database
                        update_cursor.execute("UPDATE settings SET setting_value = %s WHERE setting_key = %s", 
                                    (payment_methods_str, 'payment_methods'))
                        
                        # Remove from form_data to avoid processing it again
                        form_data.pop('payment_methods[]', None)
                    
                    # Process all other settings (non-array values)
                    for key, values in form_data.items():
                        # Skip any keys that end with [] which are arrays
                        if key.endswith('[]'):
                            continue
                            
                        # Get the first value if it's a list
                        value = values[0] if isinstance(values, list) else values
                        
                        # Skip the form_type field as it's just for form identification
                        if key == 'form_type':
                            continue
                            
                        # Check if this setting already exists
                        update_cursor.execute("SELECT * FROM settings WHERE setting_key = %s", (key,))
                        if update_cursor.fetchone():
                            # Update existing setting
                            update_cursor.execute("UPDATE settings SET setting_value = %s WHERE setting_key = %s", 
                                        (value, key))
                        else:
                            # Insert new setting
                            update_cursor.execute("INSERT INTO settings (setting_key, setting_value) VALUES (%s, %s)",
                                        (key, value))
                
                # Commit changes after all updates are done
                conn.commit()
                flash('Settings updated successfully', 'success')
            except Exception as e:
                conn.rollback()
                flash(f'Error saving settings: {str(e)}', 'error')
                print(f"Error in settings POST: {e}")
            
            return redirect(url_for('admin.settings'))
            
        # Pass current datetime to the template for display
        from datetime import datetime
        now = datetime.now()
        
        # Ensure payment_methods is initialized properly
        if 'payment_methods' not in settings_dict:
            settings_dict['payment_methods'] = []
        elif isinstance(settings_dict['payment_methods'], str):
            settings_dict['payment_methods'] = settings_dict['payment_methods'].split(',')
        
        return render_template('admin/settings.html', settings=settings_dict, now=now)
    except Exception as e:
        print(f"Error in settings: {e}")
        flash(f"Error: {str(e)}", "error")
        # Pass current datetime to the template for display
        from datetime import datetime
        now = datetime.now()
        
        # Create a minimal settings dict with empty payment_methods to avoid template errors
        empty_settings = {'payment_methods': []}
        
        return render_template('admin/settings.html', settings=empty_settings, error=str(e), now=now)
    finally:
        conn.close()

@admin_bp.route('/api/update-quantity', methods=['POST'])
@admin_required
def update_quantity():
    data = request.json
    product_id = data.get('product_id')
    quantity = data.get('quantity')
    
    if not product_id or quantity is None:
        return jsonify({'status': 'error', 'message': 'Missing required parameters'}), 400
    
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("UPDATE products SET quantity=%s WHERE id=%s", (quantity, product_id))
        conn.commit()
        return jsonify({'status': 'success', 'message': 'Quantity updated successfully'})
    except Exception as e:
        conn.rollback()
        return jsonify({'status': 'error', 'message': str(e)}), 500
    finally:
        conn.close()

@admin_bp.route('/profile', methods=['GET', 'POST'])
@admin_required
def profile():
    conn = get_db_connection()
    try:
        if request.method == 'POST':
            # Check if it's an avatar update
            if request.form.get('action') == 'update_avatar':
                if 'avatar' not in request.files:
                    flash('No file uploaded', 'error')
                    return redirect(url_for('admin.profile'))
                    
                avatar_file = request.files['avatar']
                if avatar_file.filename == '':
                    flash('No file selected', 'error')
                    return redirect(url_for('admin.profile'))
                
                if avatar_file and allowed_file(avatar_file.filename, ['png', 'jpg', 'jpeg', 'gif']):
                    # Create avatars directory if it doesn't exist
                    avatar_path = os.path.join('static', 'uploads', 'avatars')
                    os.makedirs(avatar_path, exist_ok=True)
                    
                    # Create a unique filename
                    filename = secure_filename(avatar_file.filename)
                    user_id = session.get('user_id')
                    unique_filename = f"avatar_{user_id}_{filename}"
                    file_path = os.path.join(avatar_path, unique_filename)
                    
                    # Save the file
                    avatar_file.save(file_path)
                    
                    # The avatar path to store in database (relative to static)
                    db_avatar_path = f"uploads/avatars/{unique_filename}"
                    
                    # Update user's avatar in database
                    with conn.cursor() as cursor:
                        cursor.execute(
                            "UPDATE users SET avatar_path=%s, updated_at=NOW() WHERE id=%s",
                            (db_avatar_path, user_id)
                        )
                    conn.commit()
                    
                    # Update session
                    session['avatar'] = db_avatar_path
                    
                    flash('Avatar updated successfully', 'success')
                    return redirect(url_for('admin.profile'))
                else:
                    flash('Invalid file type. Please upload an image file (png, jpg, jpeg, gif)', 'error')
                    return redirect(url_for('admin.profile'))
            
            # Get form data
            name = request.form.get('name')
            email = request.form.get('email')
            phone = request.form.get('phone')
            current_password = request.form.get('current_password')
            new_password = request.form.get('new_password')
            confirm_password = request.form.get('confirm_password')
            
            # Validate form data
            if not name or not email:
                flash('Name and email are required', 'error')
                return redirect(url_for('admin.profile'))
            
            # Get admin details
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM users WHERE id = %s", (session.get('user_id'),))
                user = cursor.fetchone()
                
                if not user:
                    flash('User not found', 'error')
                    return redirect(url_for('admin.profile'))
                
            # Update basic information
            with conn.cursor() as cursor:
                cursor.execute("""
                    UPDATE users 
                    SET name=%s, email=%s, phone=%s, updated_at=NOW()
                    WHERE id=%s
                """, (name, email, phone or None, session.get('user_id')))
            
            # Update password if requested
            if current_password and new_password and confirm_password:
                if new_password != confirm_password:
                    flash('New passwords do not match', 'error')
                    return redirect(url_for('admin.profile'))
                    
                if current_password != user['password']:  # For production, use proper password hashing
                    flash('Current password is incorrect', 'error')
                    return redirect(url_for('admin.profile'))
                    
                with conn.cursor() as cursor:
                    cursor.execute("""
                        UPDATE users 
                        SET password=%s, updated_at=NOW()
                        WHERE id=%s
                    """, (new_password, session.get('user_id')))
                
            conn.commit()
            # Update session data
            session['user_name'] = name
            
            flash('Profile updated successfully', 'success')
            return redirect(url_for('admin.profile'))
                
        # Get admin details for display
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE id = %s", (session.get('user_id'),))
            user = cursor.fetchone()
            
            # Make sure avatar is in session if it exists in the database
            if user and user.get('avatar_path') and not session.get('avatar'):
                session['avatar'] = user['avatar_path']
                
            # For debugging - print the avatar path
            print(f"User avatar path: {user.get('avatar_path') if user else 'No user'}") 
            print(f"Session avatar: {session.get('avatar', 'No avatar in session')}")
            
        return render_template('admin/profile.html', user=user)
    except Exception as e:
        print(f"Error in profile: {e}")
        flash(f"Error: {str(e)}", "error")
        return render_template('admin/profile.html', error=str(e))
    finally:
        conn.close()