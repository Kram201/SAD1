from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app, session
import os
from datetime import datetime
from werkzeug.utils import secure_filename
from backend.database import get_db_connection

# Create blueprint
inventory_bp = Blueprint('inventory', __name__, url_prefix='/admin/inventory')

@inventory_bp.route('/')
def index():
    """Display all products with inventory information"""
    if 'admin_id' not in session:
        flash('Please log in to access the admin area', 'error')
        return redirect(url_for('auth.login'))
        
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Get all products with their categories
        cursor.execute("""
            SELECT p.*, c.name as category_name,
            CASE 
                WHEN p.quantity <= 0 THEN 'Out of Stock'
                WHEN p.quantity <= p.min_quantity THEN 'Low Stock'
                ELSE 'In Stock'
            END AS stock_status
            FROM products p
            JOIN categories c ON p.category_id = c.id
            ORDER BY p.id DESC
        """)
        products = cursor.fetchall()
        
        # Get categories for the filter
        cursor.execute("SELECT * FROM categories ORDER BY name")
        categories = cursor.fetchall()
        
        # Get inventory summary
        cursor.execute("""
            SELECT 
                COUNT(*) as total_products,
                SUM(CASE WHEN quantity > 0 THEN 1 ELSE 0 END) as in_stock,
                SUM(CASE WHEN quantity <= min_quantity AND quantity > 0 THEN 1 ELSE 0 END) as low_stock,
                SUM(CASE WHEN quantity <= 0 THEN 1 ELSE 0 END) as out_of_stock
            FROM products
        """)
        inventory_summary = cursor.fetchone()
        
        return render_template('admin/inventory/index.html', 
                              products=products, 
                              categories=categories,
                              inventory_summary=inventory_summary)
    finally:
        conn.close()

@inventory_bp.route('/low-stock')
def low_stock():
    """Display products with low stock"""
    if 'admin_id' not in session:
        flash('Please log in to access the admin area', 'error')
        return redirect(url_for('auth.login'))
        
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Call the procedure to get low stock products
        cursor.execute("CALL get_low_stock_products()")
        products = cursor.fetchall()
        
        return render_template('admin/inventory/low_stock.html', products=products)
    finally:
        conn.close()

@inventory_bp.route('/update-quantity', methods=['POST'])
def update_quantity():
    """Update product quantity via AJAX"""
    if 'admin_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
        
    data = request.get_json()
    product_id = data.get('product_id')
    quantity = data.get('quantity')
    
    if not product_id or quantity is None:
        return jsonify({'success': False, 'message': 'Missing product ID or quantity'}), 400
        
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Get current quantity
        cursor.execute("SELECT quantity FROM products WHERE id = %s", (product_id,))
        product = cursor.fetchone()
        
        if not product:
            return jsonify({'success': False, 'message': 'Product not found'}), 404
        
        old_quantity = product['quantity']
        
        # Call the procedure to update quantity
        cursor.execute("CALL update_product_quantity(%s, %s)", (product_id, quantity))
        updated_product = cursor.fetchone()
        
        # Log the change
        cursor.execute("CALL log_inventory_change(%s, %s, %s, %s, %s, %s)", 
                     (product_id, old_quantity, quantity, session.get('admin_id'), 
                      'manual_update', f'Updated by admin via dashboard'))
        
        conn.commit()
        
        return jsonify({
            'success': True, 
            'message': 'Quantity updated successfully',
            'stock_status': updated_product['stock_status'],
            'quantity': updated_product['quantity']
        })
    except Exception as e:
        conn.rollback()
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500
    finally:
        conn.close()

@inventory_bp.route('/inventory-log')
def inventory_log():
    """Display inventory change log"""
    if 'admin_id' not in session:
        flash('Please log in to access the admin area', 'error')
        return redirect(url_for('auth.login'))
        
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Get inventory log with product and user details
        cursor.execute("""
            SELECT l.*, p.name as product_name, u.name as user_name
            FROM inventory_log l
            JOIN products p ON l.product_id = p.id
            LEFT JOIN users u ON l.user_id = u.id
            ORDER BY l.created_at DESC
            LIMIT 100
        """)
        logs = cursor.fetchall()
        
        return render_template('admin/inventory/log.html', logs=logs)
    finally:
        conn.close()

@inventory_bp.route('/delete-product/<int:product_id>', methods=['GET', 'POST'])
def delete_product(product_id):
    """Delete a product from the inventory"""
    if 'admin_id' not in session:
        flash('Please log in to access the admin area', 'error')
        return redirect(url_for('auth.login'))
        
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Get product details for logging
        cursor.execute("SELECT * FROM products WHERE id = %s", (product_id,))
        product = cursor.fetchone()
        
        if not product:
            flash('Product not found', 'error')
            return redirect(url_for('inventory.index'))
        
        # Delete the product
        cursor.execute("DELETE FROM products WHERE id = %s", (product_id,))
        
        # Log the deletion in inventory_log
        try:
            cursor.execute("CALL log_inventory_change(%s, %s, %s, %s, %s, %s)", 
                        (product_id, product['quantity'], 0, session.get('admin_id'), 
                        'delete', f"Product '{product['name']}' deleted"))
        except Exception as e:
            # Continue even if logging fails
            print(f"Error logging product deletion: {e}")
        
        conn.commit()
        flash('Product deleted successfully', 'success')
        
    except Exception as e:
        conn.rollback()
        flash(f'Error deleting product: {str(e)}', 'error')
    finally:
        conn.close()
        
    return redirect(url_for('inventory.index'))

def register_inventory_routes(app):
    """Register the blueprint with the Flask application"""
    app.register_blueprint(inventory_bp)
    
    # Register admin routes
    @app.route('/admin/delete_product/<int:product_id>', methods=['GET', 'POST'])
    def admin_delete_product(product_id):
        """Handle product deletion from the original admin route"""
        if 'admin_id' not in session:
            flash('Please log in to access the admin area', 'error')
            return redirect(url_for('auth.login'))
            
        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            
            # Get product details for logging
            cursor.execute("SELECT * FROM products WHERE id = %s", (product_id,))
            product = cursor.fetchone()
            
            if not product:
                flash('Product not found', 'error')
                return redirect(url_for('admin.products'))
            
            # Delete the product
            cursor.execute("DELETE FROM products WHERE id = %s", (product_id,))
            
            # Log the deletion in inventory_log
            try:
                cursor.execute("CALL log_inventory_change(%s, %s, %s, %s, %s, %s)", 
                            (product_id, product['quantity'], 0, session.get('admin_id'), 
                            'delete', f"Product '{product['name']}' deleted"))
            except Exception as e:
                # Continue even if logging fails
                print(f"Error logging product deletion: {e}")
            
            conn.commit()
            flash('Product deleted successfully', 'success')
            
        except Exception as e:
            conn.rollback()
            flash(f'Error deleting product: {str(e)}', 'error')
        finally:
            conn.close()
            
        return redirect(url_for('admin.products'))
