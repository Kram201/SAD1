from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from functools import wraps
import pymysql
import os
import sys
from datetime import datetime

# Add parent directory to path to make imports work
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import get_db_connection

customer_bp = Blueprint('customer', __name__, url_prefix='/customer')

# Auth middleware
def customer_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'customer':
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

@customer_bp.route('/dashboard')
@customer_required
def dashboard():
    user_id = session['user_id']
    conn = get_db_connection()
    try:
        # Get recent orders
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT * FROM orders 
                WHERE customer_id = %s 
                ORDER BY created_at DESC 
                LIMIT 5
            """, (user_id,))
            recent_orders = cursor.fetchall()
            
        # Get order stats
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_orders,
                    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
                    SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) as processing_orders
                FROM orders
                WHERE customer_id = %s
            """, (user_id,))
            order_stats = cursor.fetchone()
            
        # Add pagination variables to be consistent with templates
        total_pages = 1
        current_page = 1
        
        return render_template('customer/dashboard.html',
                              recent_orders=recent_orders,
                              order_stats=order_stats,
                              total_pages=total_pages,
                              current_page=current_page)
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return render_template('customer/dashboard.html', error=str(e))
    finally:
        conn.close()

@customer_bp.route('/products')
@customer_required
def products():
    category_id = request.args.get('category', None)
    search = request.args.get('search', '')
    
    conn = get_db_connection()
    try:
        # Get all categories for filter
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM categories ORDER BY name")
            categories = cursor.fetchall()
        
        # Get products with filtering
        with conn.cursor() as cursor:
            query = """
                SELECT p.*, c.name as category_name 
                FROM products p
                JOIN categories c ON p.category_id = c.id
                WHERE 1=1
            """
            params = []
            
            if category_id:
                query += " AND p.category_id = %s"
                params.append(category_id)
                
            if search:
                query += " AND (p.name LIKE %s OR p.description LIKE %s)"
                params.extend([f"%{search}%", f"%{search}%"])
                
            query += " ORDER BY p.name"
            cursor.execute(query, params)
            products = cursor.fetchall()
            
        # Add pagination variables to be consistent with admin templates
        total_pages = 1  # For now, all products are shown on one page
        current_page = 1
        
        return render_template('customer/products.html',
                              products=products,
                              categories=categories,
                              selected_category=category_id,
                              search_query=search,
                              total_pages=total_pages,
                              current_page=current_page)
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return render_template('customer/products.html', error=str(e))
    finally:
        conn.close()

@customer_bp.route('/product/<int:product_id>')
@customer_required
def product_detail(product_id):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT p.*, c.name as category_name 
                FROM products p
                JOIN categories c ON p.category_id = c.id
                WHERE p.id = %s
            """, (product_id,))
            product = cursor.fetchone()
            
            if not product:
                flash('Product not found', 'error')
                return redirect(url_for('customer.products'))
            
            # Get related products in the same category
            cursor.execute("""
                SELECT * FROM products 
                WHERE category_id = %s AND id != %s
                LIMIT 4
            """, (product['category_id'], product_id))
            related_products = cursor.fetchall()
            
        # Add pagination variables for template consistency
        total_pages = 1  # Single product view doesn't need pagination
        current_page = 1
        
        return render_template('customer/product_detail.html',
                              product=product,
                              related_products=related_products,
                              total_pages=total_pages,
                              current_page=current_page)
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('customer.products'))
    finally:
        conn.close()

@customer_bp.route('/cart')
@customer_required
def cart():
    cart_items = session.get('cart', [])
    
    if not cart_items:
        return render_template('customer/cart.html', cart_items=[], total=0)
    
    # Get product details from database
    conn = get_db_connection()
    try:
        product_ids = [item['product_id'] for item in cart_items]
        placeholders = ', '.join(['%s'] * len(product_ids))
        
        with conn.cursor() as cursor:
            cursor.execute(f"SELECT * FROM products WHERE id IN ({placeholders})", product_ids)
            products = {product['id']: product for product in cursor.fetchall()}
        
        # Combine product details with cart quantities
        for item in cart_items:
            item['product'] = products.get(item['product_id'])
            item['subtotal'] = item['product']['price'] * item['quantity']
        
        total = sum(item['subtotal'] for item in cart_items)
        
        return render_template('customer/cart.html',
                              cart_items=cart_items,
                              total=total)
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return render_template('customer/cart.html', cart_items=[], total=0, error=str(e))
    finally:
        conn.close()

@customer_bp.route('/add-to-cart', methods=['POST'])
@customer_required
def add_to_cart():
    product_id = int(request.form.get('product_id'))
    quantity = int(request.form.get('quantity', 1))
    
    if quantity < 1:
        flash('Quantity must be at least 1', 'error')
        return redirect(url_for('customer.product_detail', product_id=product_id))
    
    # Check stock
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM products WHERE id = %s", (product_id,))
            product = cursor.fetchone()
            
            if not product:
                flash('Product not found', 'error')
                return redirect(url_for('customer.products'))
            
            if product['quantity'] < quantity:
                flash(f'Sorry, only {product["quantity"]} items in stock', 'error')
                return redirect(url_for('customer.product_detail', product_id=product_id))
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('customer.product_detail', product_id=product_id))
    finally:
        conn.close()
    
    # Add to cart in session
    cart = session.get('cart', [])
    
    # Check if product already in cart
    for item in cart:
        if item['product_id'] == product_id:
            item['quantity'] += quantity
            session['cart'] = cart
            flash('Cart updated', 'success')
            return redirect(url_for('customer.cart'))
    
    # Add new item to cart
    cart.append({
        'product_id': product_id,
        'quantity': quantity
    })
    session['cart'] = cart
    
    flash('Added to cart', 'success')
    return redirect(url_for('customer.cart'))

@customer_bp.route('/update-cart', methods=['POST'])
@customer_required
def update_cart():
    product_id = int(request.form.get('product_id'))
    quantity = int(request.form.get('quantity'))
    
    if quantity < 1:
        return remove_from_cart()
    
    cart = session.get('cart', [])
    
    for item in cart:
        if item['product_id'] == product_id:
            # Check stock before updating
            conn = get_db_connection()
            try:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT quantity FROM products WHERE id = %s", (product_id,))
                    product = cursor.fetchone()
                    
                    if product and product['quantity'] >= quantity:
                        item['quantity'] = quantity
                        flash('Cart updated', 'success')
                    else:
                        flash(f'Sorry, only {product["quantity"]} items in stock', 'error')
            except Exception as e:
                flash(f'Error: {str(e)}', 'error')
            finally:
                conn.close()
            break
    
    session['cart'] = cart
    return redirect(url_for('customer.cart'))

@customer_bp.route('/remove-from-cart', methods=['POST'])
@customer_required
def remove_from_cart():
    product_id = int(request.form.get('product_id'))
    
    cart = session.get('cart', [])
    cart = [item for item in cart if item['product_id'] != product_id]
    session['cart'] = cart
    
    flash('Item removed from cart', 'success')
    return redirect(url_for('customer.cart'))

@customer_bp.route('/checkout', methods=['GET', 'POST'])
@customer_required
def checkout():
    cart_items = session.get('cart', [])
    
    if not cart_items:
        flash('Your cart is empty', 'info')
        return redirect(url_for('customer.products'))
    
    if request.method == 'POST':
        user_id = session['user_id']
        shipping_address = request.form.get('shipping_address')
        payment_method = request.form.get('payment_method')
        
        conn = get_db_connection()
        try:
            conn.begin()  # Start transaction
            
            # Create order
            with conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO orders (customer_id, shipping_address, payment_method, status, created_at)
                    VALUES (%s, %s, %s, 'pending', NOW())
                """, (user_id, shipping_address, payment_method))
                order_id = cursor.lastrowid
            
            # Get product details and insert order items
            total_amount = 0
            product_ids = [item['product_id'] for item in cart_items]
            placeholders = ', '.join(['%s'] * len(product_ids))
            
            with conn.cursor() as cursor:
                cursor.execute(f"SELECT * FROM products WHERE id IN ({placeholders})", product_ids)
                products = {product['id']: product for product in cursor.fetchall()}
            
                # Insert order items and update inventory
                for item in cart_items:
                    product = products.get(item['product_id'])
                    quantity = item['quantity']
                    price = product['price']
                    subtotal = price * quantity
                    total_amount += subtotal
                    
                    # Insert order item
                    cursor.execute("""
                        INSERT INTO order_items (order_id, product_id, quantity, price, subtotal)
                        VALUES (%s, %s, %s, %s, %s)
                    """, (order_id, item['product_id'], quantity, price, subtotal))
                    
                    # Update inventory
                    cursor.execute("""
                        UPDATE products
                        SET quantity = quantity - %s
                        WHERE id = %s
                    """, (quantity, item['product_id']))
                
                # Update order total
                cursor.execute("UPDATE orders SET total_amount = %s WHERE id = %s", (total_amount, order_id))
            
            conn.commit()
            
            # Clear cart
            session['cart'] = []
            
            flash('Order placed successfully!', 'success')
            return redirect(url_for('customer.order_confirmation', order_id=order_id))
            
        except Exception as e:
            conn.rollback()
            flash(f'Error placing order: {str(e)}', 'error')
            return redirect(url_for('customer.checkout'))
        finally:
            conn.close()
    
    # GET request - show checkout form
    conn = get_db_connection()
    try:
        # Get customer info
        user_id = session['user_id']
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM customers WHERE id = %s", (user_id,))
            customer = cursor.fetchone()
        
        # Get product details from database
        product_ids = [item['product_id'] for item in cart_items]
        placeholders = ', '.join(['%s'] * len(product_ids))
        
        with conn.cursor() as cursor:
            cursor.execute(f"SELECT * FROM products WHERE id IN ({placeholders})", product_ids)
            products = {product['id']: product for product in cursor.fetchall()}
        
        # Combine product details with cart quantities
        for item in cart_items:
            item['product'] = products.get(item['product_id'])
            item['subtotal'] = item['product']['price'] * item['quantity']
        
        total = sum(item['subtotal'] for item in cart_items)
        
        # Add pagination variables
        total_pages = 1
        current_page = 1
        
        return render_template('customer/checkout.html',
                              cart_items=cart_items,
                              total=total,
                              customer=customer,
                              total_pages=total_pages,
                              current_page=current_page)
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('customer.cart'))
    finally:
        conn.close()

@customer_bp.route('/order-confirmation/<int:order_id>')
@customer_required
def order_confirmation(order_id):
    user_id = session['user_id']
    
    conn = get_db_connection()
    try:
        # Get order details
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT * FROM orders WHERE id = %s AND customer_id = %s
            """, (order_id, user_id))
            order = cursor.fetchone()
            
            if not order:
                flash('Order not found', 'error')
                return redirect(url_for('customer.orders'))
            
            # Get order items
            cursor.execute("""
                SELECT oi.*, p.name, p.image_path
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                WHERE oi.order_id = %s
            """, (order_id,))
            order_items = cursor.fetchall()
        
        # Add pagination variables
        total_pages = 1
        current_page = 1
        
        return render_template('customer/order_confirmation.html',
                              order=order,
                              order_items=order_items,
                              total_pages=total_pages,
                              current_page=current_page)
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('customer.orders'))
    finally:
        conn.close()

@customer_bp.route('/orders')
@customer_required
def orders():
    user_id = session['user_id']
    
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT * FROM orders 
                WHERE customer_id = %s 
                ORDER BY created_at DESC
            """, (user_id,))
            orders = cursor.fetchall()
        
        # Add pagination variables
        total_pages = 1
        current_page = 1
        
        return render_template('customer/orders.html', 
                              orders=orders,
                              total_pages=total_pages,
                              current_page=current_page)
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return render_template('customer/orders.html', orders=[], error=str(e))
    finally:
        conn.close()

@customer_bp.route('/order/<int:order_id>')
@customer_required
def order_detail(order_id):
    user_id = session['user_id']
    
    conn = get_db_connection()
    try:
        # Get order details
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT * FROM orders WHERE id = %s AND customer_id = %s
            """, (order_id, user_id))
            order = cursor.fetchone()
            
            if not order:
                flash('Order not found', 'error')
                return redirect(url_for('customer.orders'))
            
            # Get order items
            cursor.execute("""
                SELECT oi.*, p.name, p.image_path
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                WHERE oi.order_id = %s
            """, (order_id,))
            order_items = cursor.fetchall()
        
        # Add pagination variables
        total_pages = 1
        current_page = 1
        
        return render_template('customer/order_detail.html',
                              order=order,
                              order_items=order_items,
                              total_pages=total_pages,
                              current_page=current_page)
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('customer.orders'))
    finally:
        conn.close()