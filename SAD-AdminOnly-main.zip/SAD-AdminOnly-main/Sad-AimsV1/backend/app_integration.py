from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import os
import datetime
from werkzeug.utils import secure_filename
from inventory_manager import (
    init_app, get_all_products, get_product, add_product, 
    update_product, delete_product, update_quantity
)

# Example of how to integrate with your Flask app routes

def register_inventory_routes(app):
    """Register inventory routes with the Flask app"""
    # Initialize the database connection handler
    init_app(app)

    # The following routes should be integrated with your existing routes
    # They show how to use the inventory_manager functions

    @app.route('/admin/inventory')
    def admin_inventory():
        """Display all products in inventory"""
        products = get_all_products()
        return render_template('admin/inventory/index.html', products=products)

    @app.route('/admin/add_product', methods=['GET', 'POST'])
    def admin_add_product():
        if request.method == 'POST':
            # Extract form data
            name = request.form.get('name')
            description = request.form.get('description')
            category_id = int(request.form.get('category_id'))
            category_name = request.form.get('category_name')
            quantity = int(request.form.get('quantity', 0))
            min_quantity = int(request.form.get('min_quantity', 5))
            entry_price = float(request.form.get('entry_price'))
            price = float(request.form.get('price'))
            
            # Handle image upload
            image_path = None
            if 'image' in request.files and request.files['image'].filename:
                image = request.files['image']
                filename = secure_filename(image.filename)
                # Create unique filename to avoid overwriting
                timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
                save_filename = f"{timestamp}_{filename}"
                upload_folder = os.path.join(app.static_folder, 'uploads/products')
                os.makedirs(upload_folder, exist_ok=True)
                file_path = os.path.join(upload_folder, save_filename)
                image.save(file_path)
                # Store path relative to static folder
                image_path = f"/static/uploads/products/{save_filename}"
            
            # Add to database
            product_id = add_product(
                name, description, category_id, category_name,
                quantity, min_quantity, entry_price, price, image_path
            )
            
            if product_id:
                flash('Product added successfully!', 'success')
                return redirect(url_for('admin_inventory'))
            else:
                flash('Error adding product', 'error')
                
        # For GET request, show the form
        categories = []  # You should load categories from your database
        return render_template('admin/inventory/add.html', categories=categories)

    @app.route('/admin/edit_product/<int:product_id>', methods=['GET', 'POST'])
    def admin_edit_product(product_id):
        # Get existing product
        product = get_product(product_id)
        if not product:
            flash('Product not found', 'error')
            return redirect(url_for('admin_inventory'))
            
        if request.method == 'POST':
            # Extract form data
            updates = {
                'name': request.form.get('name'),
                'description': request.form.get('description'),
                'category_id': int(request.form.get('category_id')),
                'category_name': request.form.get('category_name'),
                'quantity': int(request.form.get('quantity', 0)),
                'min_quantity': int(request.form.get('min_quantity', 5)),
                'entry_price': float(request.form.get('entry_price')),
                'price': float(request.form.get('price'))
            }
            
            # Handle image upload
            if 'image' in request.files and request.files['image'].filename:
                image = request.files['image']
                filename = secure_filename(image.filename)
                # Create unique filename to avoid overwriting
                timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
                save_filename = f"{timestamp}_{filename}"
                upload_folder = os.path.join(app.static_folder, 'uploads/products')
                os.makedirs(upload_folder, exist_ok=True)
                file_path = os.path.join(upload_folder, save_filename)
                image.save(file_path)
                # Store path relative to static folder
                updates['image_path'] = f"/static/uploads/products/{save_filename}"
            
            # Update in database
            success = update_product(product_id, **updates)
            
            if success:
                flash('Product updated successfully!', 'success')
                return redirect(url_for('admin_inventory'))
            else:
                flash('Error updating product', 'error')
                
        # For GET request, show the form with existing data
        categories = []  # You should load categories from your database
        return render_template('admin/inventory/edit.html', product=product, categories=categories)

    @app.route('/admin/delete_product/<int:product_id>', methods=['POST'])
    def admin_delete_product(product_id):
        success = delete_product(product_id)
        if success:
            flash('Product deleted successfully!', 'success')
        else:
            flash('Error deleting product', 'error')
        return redirect(url_for('admin_inventory'))

    @app.route('/admin/update_quantity', methods=['POST'])
    def admin_update_quantity():
        data = request.get_json()
        product_id = data.get('product_id')
        quantity = data.get('quantity')
        
        if not product_id or quantity is None:
            return jsonify({'success': False, 'message': 'Missing product ID or quantity'}), 400
            
        success = update_quantity(product_id, quantity)
        
        if success:
            return jsonify({
                'success': True, 
                'message': 'Quantity updated successfully',
                'quantity': quantity
            })
        else:
            return jsonify({'success': False, 'message': 'Error updating quantity'}), 500

    # Return the functions so they can be used elsewhere if needed
    return {
        'admin_inventory': admin_inventory,
        'admin_add_product': admin_add_product,
        'admin_edit_product': admin_edit_product,
        'admin_delete_product': admin_delete_product,
        'admin_update_quantity': admin_update_quantity
    }
