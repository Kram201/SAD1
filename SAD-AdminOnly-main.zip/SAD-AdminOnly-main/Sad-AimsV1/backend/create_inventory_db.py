import sqlite3
import os

# Ensure the directory exists for the database
os.makedirs(os.path.dirname(os.path.abspath(__file__)), exist_ok=True)

# Connect to the SQLite database (creates it if it doesn't exist)
conn = sqlite3.connect('inventory.db')
cursor = conn.cursor()

# Create products table
cursor.execute('''
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    category_id INTEGER NOT NULL,
    category_name TEXT NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 0,
    min_quantity INTEGER NOT NULL DEFAULT 5,
    entry_price REAL NOT NULL,
    price REAL NOT NULL,
    image_path TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
''')

# Insert the 5 existing products
products = [
    (1, 'Kolin Window Type Aircon', '1.0HP Window Type Air Conditioner with Energy Saving Features', 
     1, 'Window Type', 42, 11, 198.00, 789.00, '/static/uploads/products/kolin-window.jpg'),
    
    (2, 'Panasonic Window Type Aircon', '1.5HP Window Type Air Conditioner with Inverter Technology', 
     1, 'Window Type', 17, 8, 900.00, 934.00, '/static/uploads/products/panasonic-window.jpg'),
    
    (3, 'Carrier Window Type Aircon', '1.0HP Window Type Air Conditioner with Remote Control', 
     1, 'Window Type', 21, 12, 634.00, 567.00, '/static/uploads/products/carrier-window.jpg'),
    
    (4, 'Fujitsu Window Type Aircon', '2.0HP Window Type Air Conditioner with Smart Features', 
     1, 'Window Type', 73, 10, 547.00, 234.00, '/static/uploads/products/fujitsu-window.jpg'),
    
    (5, 'LG Split Type Aircon', '1.5HP Split Type Air Conditioner with WiFi Control', 
     2, 'Split Type', 15, 5, 1200.00, 1500.00, '/static/uploads/products/lg-split.jpg')
]

# Check if data already exists before inserting
cursor.execute("SELECT COUNT(*) FROM products")
count = cursor.fetchone()[0]

if count == 0:
    cursor.executemany('''
    INSERT INTO products (id, name, description, category_id, category_name, 
                         quantity, min_quantity, entry_price, price, image_path)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', products)
    print("Initial product data inserted successfully.")
else:
    print(f"Database already contains {count} products. Skipping initial data insertion.")

# Commit changes and close connection
conn.commit()
conn.close()

print("Inventory database setup complete!")
