class Config:
    # Application settings
    SECRET_KEY = 'your_secret_key_here'  # Replace with a secure random key in production
    
    # Database settings for MySQL with XAMPP
    DB_HOST = 'localhost'
    DB_USER = 'root'
    DB_PASSWORD = ''  # Default XAMPP MySQL has no password
    DB_NAME = 'aircon_inventory_db'
    
    # Upload settings
    UPLOAD_FOLDER = 'static/uploads'
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}