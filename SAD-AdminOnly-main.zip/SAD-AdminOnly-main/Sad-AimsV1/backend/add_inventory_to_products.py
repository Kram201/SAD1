import sys
import os
from datetime import datetime
import json

# Set up path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import database connection
from backend.database import get_db_connection

def run_migration():
    """Add inventory fields to existing products table if not already present"""
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Check if the products table has the new inventory fields
        cursor.execute("SHOW COLUMNS FROM products")
        columns = [column['Field'] for column in cursor.fetchall()]
        
        # Define the columns we need to add for inventory management
        columns_to_add = {
            'min_quantity': 'INT NOT NULL DEFAULT 5',
            'status': 'TINYINT(1) NOT NULL DEFAULT 1',
            'featured': 'TINYINT(1) NOT NULL DEFAULT 0',
            'last_updated': 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
        }
        
        # Add any missing columns
        for column_name, column_def in columns_to_add.items():
            if column_name not in columns:
                print(f"Adding column '{column_name}' to products table")
                cursor.execute(f"ALTER TABLE products ADD COLUMN {column_name} {column_def}")
        
        # Make sure the quantity column has a DEFAULT 0 constraint if it exists
        if 'quantity' in columns:
            cursor.execute("ALTER TABLE products MODIFY quantity INT NOT NULL DEFAULT 0")
        
        conn.commit()
        print("✅ Products table has been updated with inventory fields")
        
        # Update existing products with default inventory values
        cursor.execute("""
            UPDATE products 
            SET min_quantity = 5, 
                status = 1,
                featured = 0,
                last_updated = NOW()
            WHERE quantity IS NOT NULL AND min_quantity IS NULL
        """)
        conn.commit()
        print("✅ Existing products updated with default inventory values")
        
        return True
    except Exception as e:
        print(f"❌ Error updating products table: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

def create_inventory_procedures():
    """Create stored procedures for inventory management"""
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Procedure to update product quantity
        cursor.execute("""
        DROP PROCEDURE IF EXISTS update_product_quantity;
        """)
        
        cursor.execute("""
        CREATE PROCEDURE update_product_quantity(
            IN p_product_id INT,
            IN p_quantity INT
        )
        BEGIN
            UPDATE products
            SET quantity = p_quantity,
                last_updated = NOW()
            WHERE id = p_product_id;
            
            SELECT 
                id, 
                quantity, 
                min_quantity,
                CASE 
                    WHEN quantity <= 0 THEN 'Out of Stock'
                    WHEN quantity <= min_quantity THEN 'Low Stock'
                    ELSE 'In Stock'
                END AS stock_status
            FROM products
            WHERE id = p_product_id;
        END;
        """)
        
        # Procedure to get low stock products
        cursor.execute("""
        DROP PROCEDURE IF EXISTS get_low_stock_products;
        """)
        
        cursor.execute("""
        CREATE PROCEDURE get_low_stock_products()
        BEGIN
            SELECT 
                p.*,
                c.name as category_name,
                CASE 
                    WHEN p.quantity <= 0 THEN 'Out of Stock'
                    WHEN p.quantity <= p.min_quantity THEN 'Low Stock'
                    ELSE 'In Stock'
                END AS stock_status
            FROM products p
            JOIN categories c ON p.category_id = c.id
            WHERE p.quantity <= p.min_quantity AND p.status = 1
            ORDER BY p.quantity ASC;
        END;
        """)
        
        # Trigger to track inventory changes
        cursor.execute("""
        DROP TABLE IF EXISTS inventory_log;
        """)
        
        cursor.execute("""
        CREATE TABLE inventory_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            old_quantity INT,
            new_quantity INT,
            user_id INT,
            action VARCHAR(50) NOT NULL,
            note TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        """)
        
        # Procedure to log inventory changes
        cursor.execute("""
        DROP PROCEDURE IF EXISTS log_inventory_change;
        """)
        
        cursor.execute("""
        CREATE PROCEDURE log_inventory_change(
            IN p_product_id INT,
            IN p_old_quantity INT,
            IN p_new_quantity INT,
            IN p_user_id INT,
            IN p_action VARCHAR(50),
            IN p_note TEXT
        )
        BEGIN
            INSERT INTO inventory_log (
                product_id, old_quantity, new_quantity, 
                user_id, action, note
            ) VALUES (
                p_product_id, p_old_quantity, p_new_quantity, 
                p_user_id, p_action, p_note
            );
        END;
        """)
        
        conn.commit()
        print("✅ Inventory procedures created successfully")
        return True
    except Exception as e:
        print(f"❌ Error creating inventory procedures: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

if __name__ == "__main__":
    print("Starting inventory system integration...")
    
    # Run the database migration
    migration_success = run_migration()
    
    # Create stored procedures
    if migration_success:
        procedures_success = create_inventory_procedures()
        
        if procedures_success:
            print("✅ Inventory system has been successfully integrated!")
        else:
            print("❌ Failed to create inventory procedures")
    else:
        print("❌ Migration failed, cannot continue")
