from database import get_db_connection

def add_avatar_column():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # Check if column exists first to avoid errors if it already exists
            cursor.execute("""
                SELECT COUNT(*) as count
                FROM information_schema.columns 
                WHERE table_name = 'users'
                AND column_name = 'avatar_path'
                AND table_schema = DATABASE()
            """)
            result = cursor.fetchone()
            
            if result and result['count'] == 0:
                # Add the column if it doesn't exist
                cursor.execute("""
                    ALTER TABLE users 
                    ADD COLUMN avatar_path VARCHAR(255) DEFAULT NULL
                """)
                print("Avatar column added successfully!")
            else:
                print("Avatar column already exists.")
        
        conn.commit()
    except Exception as e:
        print(f"Error adding avatar column: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    add_avatar_column()
