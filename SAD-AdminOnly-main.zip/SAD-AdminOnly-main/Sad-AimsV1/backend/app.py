from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_cors import CORS
import os
from datetime import datetime
from config import Config
from database import get_db_connection

app = Flask(__name__, 
            static_folder='../static',
            template_folder='../templates')
app.config.from_object(Config)
CORS(app)

# Import routes after app is created to avoid circular imports
from routes.admin import admin_bp
from routes.customer import customer_bp
from routes.auths import auth_bp

# Register blueprints
app.register_blueprint(admin_bp)
app.register_blueprint(customer_bp)
app.register_blueprint(auth_bp)

# Secret key for session
app.secret_key = app.config['SECRET_KEY']

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)