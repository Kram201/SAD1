import sqlite3
import os
import datetime
from flask import g

# Database path
DATABASE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'inventory.db')

def get_db_connection():
    """Get a database connection, reusing it if already in the current context"""
    if 'db' not in g:
        g.db = sqlite3.connect(
            DATABASE_PATH,
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row
    return g.db

def close_db(e=None):
    """Close the database connection"""
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_app(app):
    """Register database functions with the Flask app"""
    app.teardown_appcontext(close_db)

def get_all_products():
    """Get all products from the database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products ORDER BY id")
    products = cursor.fetchall()
    return products

def get_product(product_id):
    """Get a specific product by ID"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE id = ?", (product_id,))
    product = cursor.fetchone()
    return product

def add_product(name, description, category_id, category_name, quantity, min_quantity, 
                entry_price, price, image_path=None):
    """Add a new product to the database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Get current timestamp
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    cursor.execute('''
    INSERT INTO products (name, description, category_id, category_name, quantity, 
                         min_quantity, entry_price, price, image_path, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (name, description, category_id, category_name, quantity, 
          min_quantity, entry_price, price, image_path, now, now))
    
    conn.commit()
    # Return the ID of the newly inserted product
    return cursor.lastrowid

def update_product(product_id, **kwargs):
    """Update an existing product
    
    Args:
        product_id: The ID of the product to update
        **kwargs: Fields to update (name, description, etc.)
    """
    allowed_fields = ['name', 'description', 'category_id', 'category_name', 
                      'quantity', 'min_quantity', 'entry_price', 'price', 'image_path']
    
    # Filter out invalid fields
    updates = {k: v for k, v in kwargs.items() if k in allowed_fields}
    if not updates:
        return False  # No valid fields to update
    
    # Add updated_at timestamp
    updates['updated_at'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Build the SQL query dynamically
    set_clause = ", ".join([f"{key} = ?" for key in updates.keys()])
    values = list(updates.values()) + [product_id]  # Add product_id for WHERE clause
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(f"UPDATE products SET {set_clause} WHERE id = ?", values)
    conn.commit()
    
    return cursor.rowcount > 0  # Return True if at least one row was updated

def delete_product(product_id):
    """Delete a product from the database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM products WHERE id = ?", (product_id,))
    conn.commit()
    return cursor.rowcount > 0  # Return True if at least one row was deleted

def update_quantity(product_id, new_quantity):
    """Update the quantity of a product"""
    conn = get_db_connection()
    cursor = conn.cursor()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute(
        "UPDATE products SET quantity = ?, updated_at = ? WHERE id = ?",
        (new_quantity, now, product_id)
    )
    conn.commit()
    return cursor.rowcount > 0

def search_products(query):
    """Search for products by name or description"""
    conn = get_db_connection()
    cursor = conn.cursor()
    search_pattern = f"%{query}%"
    cursor.execute("""
        SELECT * FROM products 
        WHERE name LIKE ? OR description LIKE ?
        ORDER BY name
    """, (search_pattern, search_pattern))
    return cursor.fetchall()

def get_products_by_category(category_id):
    """Get all products in a specific category"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE category_id = ? ORDER BY name", (category_id,))
    return cursor.fetchall()

def get_low_stock_products():
    """Get products with quantity below their minimum threshold"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE quantity <= min_quantity ORDER BY quantity ASC")
    return cursor.fetchall()
