$(document).ready(function () {
    // Update cart count from session
    function updateCartCount() {
        const cartItems = JSON.parse(localStorage.getItem('cart') || '[]');
        $('.cart-count').text(cartItems.length);
    }
    
    // Run initial cart count update
    updateCartCount();
    
    // Animations for stat cards
    $('.stat-card').each(function(index) {
        const card = $(this);
        setTimeout(function() {
            card.addClass('animate');
        }, index * 100);
    });
    
    // Featured products hover effects
    $('.product-item').hover(
        function() {
            $(this).addClass('shadow-lg');
        },
        function() {
            $(this).removeClass('shadow-lg');
        }
    );
    
    // Listen for cart updates
    window.addEventListener('storage', function(e) {
        if (e.key === 'cart') {
            updateCartCount();
        }
    });
    
    // Search functionality
    $('#search-form').on('submit', function(e) {
        e.preventDefault();
        const searchTerm = $('#search-input').val().trim();
        if (searchTerm) {
            window.location.href = `/customer/products?search=${encodeURIComponent(searchTerm)}`;
        }
    });
    
    // Dropdown menus
    $('.dropdown-toggle').dropdown();
    
    // Auto dismiss alerts after 5 seconds
    setTimeout(function() {
        $('.alert').alert('close');
    }, 5000);
});
