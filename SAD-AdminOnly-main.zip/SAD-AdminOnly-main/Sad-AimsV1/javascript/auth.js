$(document).ready(function () {
    // Toggle password visibility
    $('.toggle-password').on('click', function() {
        const passwordInput = $(this).closest('.input-group').find('input');
        const icon = $(this).find('i');
        
        // Toggle password visibility
        if (passwordInput.attr('type') === 'password') {
            passwordInput.attr('type', 'text');
            icon.removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            passwordInput.attr('type', 'password');
            icon.removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });
    
    // Form validation for registration
    $('form.auth-form').on('submit', function(e) {
        // Only apply to registration form
        if (window.location.pathname.includes('register')) {
            const password = $('#password').val();
            const confirmPassword = $('#confirm_password').val();
            
            // Check if passwords match
            if (password !== confirmPassword) {
                e.preventDefault();
                // Create and show error message
                showAlert('Passwords do not match.', 'danger');
                return false;
            }
            
            // Check password strength
            if (password.length < 8) {
                e.preventDefault();
                showAlert('Password must be at least 8 characters long.', 'danger');
                return false;
            }
        }
    });
    
    // Handle flash messages
    function showAlert(message, type) {
        const alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        
        $('.flash-messages').html(alertHtml);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            $('.alert').alert('close');
        }, 5000);
    }
    
    // If there are URL parameters for error messages, display them
    const urlParams = new URLSearchParams(window.location.search);
    const errorMessage = urlParams.get('error');
    const successMessage = urlParams.get('success');
    
    if (errorMessage) {
        showAlert(decodeURIComponent(errorMessage), 'danger');
    }
    
    if (successMessage) {
        showAlert(decodeURIComponent(successMessage), 'success');
    }
    
    // Form fields focus effects
    $('.form-control').on('focus', function() {
        $(this).closest('.input-group').addClass('input-group-focus');
    }).on('blur', function() {
        $(this).closest('.input-group').removeClass('input-group-focus');
    });
});
