$(document).ready(function () {
    // Toggle sidebar
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
        $('#content').toggleClass('active');
    });

    // Tooltips
    $('[data-toggle="tooltip"]').tooltip();

    // Card hover effects
    $('.card').hover(
        function() {
            $(this).addClass('shadow-lg');
        }, 
        function() {
            $(this).removeClass('shadow-lg');
        }
    );

    // Handle notifications
    $('.notification-item').on('click', function() {
        $(this).removeClass('unread');
        // Here you would normally make an AJAX call to mark as read
    });

    // Auto-update revenue display with animation
    function animateValue(elem, start, end, duration) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            const value = Math.floor(progress * (end - start) + start);
            elem.innerHTML = '₱' + value.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    }

    // Example usage for revenue animation (if the element exists)
    const revenueElement = document.querySelector('.revenue');
    if (revenueElement) {
        // Start from 0 and animate to the current value (extracted from the text)
        const currentValue = parseFloat(revenueElement.textContent.replace('₱', '').replace(/,/g, ''));
        animateValue(revenueElement, 0, currentValue, 1500);
    }

    // Fetch live stock counts via AJAX (simulated for demo)
    function updateStockCounts() {
        // This would be an AJAX call to the server in a real system
        console.log('Stock counts updated');
        
        // Simulate a call every 30 seconds
        setTimeout(updateStockCounts, 30000);
    }
    
    // Start the stock update cycle
    updateStockCounts();
});