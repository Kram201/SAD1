$(document).ready(function () {
    // Toggle sidebar
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
        $('#content').toggleClass('active');
    });

    // Category filter functionality
    $('.category-item').on('click', function() {
        $('.category-item').removeClass('active');
        $(this).addClass('active');
        
        const category = $(this).text().trim();
        
        // Filter products based on selected category
        // In a real implementation, this would likely be an AJAX call or page reload
        console.log(`Filtering by category: ${category}`);
        
        // For demo purposes, we're just logging the action
        // In a real app, you would fetch products from the server filtered by this category
    });

    // Quantity controls
    $('.btn-increase').on('click', function() {
        const quantityElem = $(this).siblings('.quantity');
        let quantity = parseInt(quantityElem.text());
        quantity++;
        
        // Update display
        quantityElem.text(quantity);
        
        // Get product info for the API call
        const productCard = $(this).closest('.product-card');
        const productId = productCard.data('product-id');
        
        // Update quantity via API
        updateProductQuantity(productId, quantity);
    });

    $('.btn-decrease').on('click', function() {
        const quantityElem = $(this).siblings('.quantity');
        let quantity = parseInt(quantityElem.text());
        if (quantity > 0) {
            quantity--;
            
            // Update display
            quantityElem.text(quantity);
            
            // Get product info for the API call
            const productCard = $(this).closest('.product-card');
            const productId = productCard.data('product-id');
            
            // Update quantity via API
            updateProductQuantity(productId, quantity);
        }
    });

    $('.btn-remove').on('click', function() {
        if (confirm('Are you sure you want to remove this product?')) {
            const productCard = $(this).closest('.product-card');
            const productId = productCard.data('product-id');
            
            // Here you would make an API call to delete the product
            console.log(`Removing product ID: ${productId}`);
            
            // Visually remove the card with animation
            const productContainer = productCard.closest('.col-md-4');
            productContainer.fadeOut(400, function() {
                $(this).remove();
            });
        }
    });

    // Function to update product quantity via API
    function updateProductQuantity(productId, quantity) {
        // In a real app, this would be an AJAX call to your backend API
        console.log(`Updating product ID ${productId} to quantity ${quantity}`);
        
        $.ajax({
            url: '/admin/api/update-quantity',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                product_id: productId,
                quantity: quantity
            }),
            success: function(response) {
                console.log('Quantity updated successfully', response);
                // You could show a success notification here
            },
            error: function(error) {
                console.error('Error updating quantity', error);
                // Revert the UI change and show error message
                alert('Failed to update quantity. Please try again.');
            }
        });
    }

    // Add data attributes to product cards for testing
    // In a real app, these would come from the server-side when rendering
    $('.product-card').each(function(index) {
        $(this).attr('data-product-id', index + 1);
    });
});