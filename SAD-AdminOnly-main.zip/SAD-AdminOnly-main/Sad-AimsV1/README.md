# Smart Aircon Inventory Management System

A comprehensive inventory management system for air conditioning units, featuring admin and customer interfaces, built with Flask, MySQL, and modern frontend technologies.

## Features

### Admin Panel
- Dashboard with revenue overview and stock statistics
- Inventory management with real-time quantity updates
- Product categorization (Window Type, Split Type, Cassette Type, Portable)
- Order processing and tracking
- Sales and inventory reports
- User management

### Customer Interface
- User registration and authentication
- Product browsing with filtering by categories
- Detailed product pages with specifications
- Shopping cart functionality
- Checkout process with multiple payment options
- Order history and tracking

## Technology Stack

- **Frontend**: HTML, CSS, JavaScript, Bootstrap 5, jQuery
- **Backend**: Python Flask
- **Database**: MySQL (via XAMPP)
- **Authentication**: Session-based authentication

## Setup Instructions

### Prerequisites
- Python 3.8 or higher
- XAMPP with MySQL
- Web browser

### Database Setup
1. Start XAMPP and ensure MySQL service is running
2. Open phpMyAdmin (http://localhost/phpmyadmin)
3. Run the database setup script from `backend/database_setup.sql`

### Installation
1. Clone this repository
2. Navigate to the project directory
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

### Running the Application
1. Start the Flask server:
   ```
   python backend/app.py
   ```
2. Access the application at: http://localhost:5000

### Default Admin Login
- Email: admin@example.com
- Password: admin123

## Project Structure

```
Sad-AimsV1/
│
├── backend/               # Server-side code
│   ├── app.py             # Main Flask application
│   ├── config.py          # Configuration settings
│   ├── database_setup.sql # Database schema and initial data
│   └── routes/            # Route handlers
│       ├── admin.py       # Admin routes
│       ├── auths.py       # Authentication routes
│       └── customer.py    # Customer routes
│
├── static/                # Static assets
│   ├── css/               # Stylesheets
│   ├── js/                # JavaScript files
│   └── uploads/           # Uploaded images
│
├── templates/             # HTML templates
│   ├── admin/             # Admin interface templates
│   ├── auth/              # Authentication templates
│   └── customer/          # Customer interface templates
│
└── requirements.txt       # Python dependencies
```

## Development Notes

- Ensure XAMPP MySQL service is running before starting the application
- The system uses session-based authentication
- Images for aircon units should be placed in `static/uploads/products`
- Default categories are created during database setup

## Future Enhancements

- Responsive design optimizations for mobile devices
- Integration with payment gateways
- Enhanced reporting features
- Email notifications for order status updates
- Product reviews and ratings
- Staff management with role-based access control

## License

This project is licensed under the MIT License.
