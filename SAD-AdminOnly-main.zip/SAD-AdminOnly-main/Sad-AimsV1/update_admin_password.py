import pymysql
import os
import sys

# Add the backend directory to the path so we can import database
sys.path.append(os.path.join(os.path.dirname(__file__), 'backend'))
from database import get_db_connection

try:
    # Connect to the database
    conn = get_db_connection()
    
    # Update admin password to plaintext
    with conn.cursor() as cursor:
        cursor.execute("UPDATE users SET password = 'admin123' WHERE email = 'admin@example.com'")
    
    # Commit changes
    conn.commit()
    print("Admin password updated to plaintext 'admin123'")
    
    # Verify update
    with conn.cursor() as cursor:
        cursor.execute("SELECT id, name, email, password FROM users WHERE email = 'admin@example.com'")
        admin = cursor.fetchone()
        if admin:
            print(f"Admin user found: ID={admin['id']}, Name={admin['name']}")
            print(f"Password is now: {admin['password']}")
        else:
            print("Admin user not found!")
            
except Exception as e:
    print(f"Error: {e}")
finally:
    if 'conn' in locals() and conn:
        conn.close()
        print("Connection closed.")
