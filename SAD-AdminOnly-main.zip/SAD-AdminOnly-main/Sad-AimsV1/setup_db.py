import pymysql
import os

# Read the SQL file
with open('backend/database_setup.sql', 'r') as f:
    sql_file = f.read()

# Split the SQL commands
sql_commands = sql_file.split(';')

# Connect to MySQL (without specifying the database)
conn = pymysql.connect(
    host='localhost',
    user='root',
    password=''
)

try:
    with conn.cursor() as cursor:
        # Execute each command
        for command in sql_commands:
            # Skip empty commands
            if command.strip():
                try:
                    cursor.execute(command)
                    print(f"Executed: {command[:50]}...")
                except Exception as e:
                    print(f"Error executing: {command[:50]}...")
                    print(f"Error: {e}")
    
    # Commit changes
    conn.commit()
    print("Database setup completed successfully!")
    
    # Test connection to the new database
    conn.close()
    conn = pymysql.connect(
        host='localhost',
        user='root',
        password='',
        db='aircon_inventory_db'
    )
    
    with conn.cursor() as cursor:
        cursor.execute('SHOW TABLES')
        tables = cursor.fetchall()
        
        print('\nTables created:')
        for table in tables:
            print(f"- {table[0]}")
    
except Exception as e:
    print(f"Error: {e}")
finally:
    conn.close()
    print("Connection closed.")
