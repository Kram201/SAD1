import pymysql

try:
    # Establish connection
    conn = pymysql.connect(
        host='localhost',
        user='root',
        password='',
        db='aircon_inventory_db'
    )
    
    print('Connection successful!')
    
    # Get tables
    cursor = conn.cursor()
    cursor.execute('SHOW TABLES')
    tables = cursor.fetchall()
    
    print('Tables in database:')
    for table in tables:
        print(f"- {table[0]}")
    
except Exception as e:
    print(f"Database connection error: {e}")
    
finally:
    if 'conn' in locals() and conn:
        conn.close()
        print("Connection closed.")
