/**
 * Aircon Inventory Admin Panel JavaScript
 * Handles all interactive elements in the admin panel
 */

$(document).ready(function() {
    // Initialize Bootstrap components
    initBootstrapComponents();
    
    // Toggle sidebar on mobile devices
    initSidebarToggle();
    
    // Setup Ajax for updating product quantities
    setupQuantityUpdaters();
    
    // Setup confirmation dialogs
    setupConfirmationDialogs();
});

/**
 * Initialize all Bootstrap components
 */
function initBootstrapComponents() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Initialize collapsible elements
    var collapseElementList = [].slice.call(document.querySelectorAll('.collapse'));
    collapseElementList.map(function(collapseEl) {
        return new bootstrap.Collapse(collapseEl, {
            toggle: false
        });
    });
    
    // Initialize dropdowns
    var dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'));
    dropdownElementList.map(function(dropdownToggleEl) {
        return new bootstrap.Dropdown(dropdownToggleEl);
    });
}

/**
 * Initialize sidebar toggle functionality
 */
function initSidebarToggle() {
    $('#sidebarCollapse').on('click', function() {
        $('#sidebar, #content').toggleClass('active');
    });
    
    // Handle submenu toggling - fix for Bootstrap 5
    $('.dropdown-toggle').on('click', function(e) {
        if ($(this).attr('href') && $(this).attr('href') !== '#' && !$(this).attr('href').startsWith('#')) {
            // If it's a real link, let it navigate
            return;
        }
        
        e.preventDefault();
        e.stopPropagation();
        
        // Get the target from href or data attribute
        var target = $(this).attr('data-bs-target') || $(this).attr('href');
        if (target.startsWith('#')) {
            $(target).collapse('toggle');
        }
    });
}

/**
 * Setup Ajax for updating product quantities
 */
function setupQuantityUpdaters() {
    $('.update-quantity').on('click', function() {
        var productId = $(this).data('product-id');
        var quantityInput = $('input[data-product-id="' + productId + '"]');
        var quantity = quantityInput.val();
        
        // Validate quantity
        if (quantity < 0 || isNaN(quantity)) {
            showAlert('Please enter a valid quantity', 'danger');
            return;
        }
        
        // Show loading indicator
        $(this).html('<i class="fas fa-spinner fa-spin"></i>');
        
        // Send update request
        $.ajax({
            url: '/admin/api/update-quantity',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                product_id: productId,
                quantity: quantity
            }),
            success: function(response) {
                if (response.status === 'success') {
                    showAlert('Quantity updated successfully', 'success');
                } else {
                    showAlert('Error: ' + response.message, 'danger');
                }
                // Restore button icon
                $('.update-quantity[data-product-id="' + productId + '"]').html('<i class="fas fa-sync-alt"></i>');
            },
            error: function(xhr, status, error) {
                showAlert('Error updating quantity: ' + error, 'danger');
                // Restore button icon
                $('.update-quantity[data-product-id="' + productId + '"]').html('<i class="fas fa-sync-alt"></i>');
            }
        });
    });
}

/**
 * Setup confirmation dialogs
 */
function setupConfirmationDialogs() {
    // Handle delete confirmations
    $('.confirm-action').on('click', function(e) {
        if (!confirm($(this).data('confirm-message') || 'Are you sure?')) {
            e.preventDefault();
        }
    });
    
    // Handle form submissions with confirmation
    $('form.confirm-submit').on('submit', function(e) {
        if (!confirm($(this).data('confirm-message') || 'Are you sure you want to submit this form?')) {
            e.preventDefault();
        }
    });
}

/**
 * Display alert message
 * @param {string} message - The message to display
 * @param {string} type - The type of alert (success, danger, warning, info)
 */
function showAlert(message, type) {
    // Create alert element
    var alertDiv = $('<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">' + 
                     message + 
                     '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                     '</div>');
    
    // Add to the alert container
    $('#alertContainer').prepend(alertDiv);
    
    // Auto-dismiss after 5 seconds
    setTimeout(function() {
        alertDiv.alert('close');
    }, 5000);
}
