$(document).ready(function () {
    // Quantity controls
    const quantityInput = $('#quantity');
    const maxQuantity = parseInt(quantityInput.attr('max'));
    
    $('.btn-increase').on('click', function() {
        let currentVal = parseInt(quantityInput.val());
        if (currentVal < maxQuantity) {
            quantityInput.val(currentVal + 1);
        }
    });
    
    $('.btn-decrease').on('click', function() {
        let currentVal = parseInt(quantityInput.val());
        if (currentVal > 1) {
            quantityInput.val(currentVal - 1);
        }
    });
    
    // Validate quantity on form submission
    $('.add-to-cart-form').on('submit', function(e) {
        const quantity = parseInt(quantityInput.val());
        
        if (quantity < 1) {
            e.preventDefault();
            alert('Please select at least 1 item');
            return false;
        }
        
        if (quantity > maxQuantity) {
            e.preventDefault();
            alert(`Sorry, only ${maxQuantity} items available in stock`);
            return false;
        }
    });
    
    // Image gallery functionality (if multiple images)
    $('.thumbnail-image').on('click', function() {
        const mainImage = $('.main-product-image');
        const thumbnailSrc = $(this).attr('src');
        const mainSrc = mainImage.attr('src');
        
        // Swap images with animation
        mainImage.fadeOut(200, function() {
            mainImage.attr('src', thumbnailSrc).fadeIn(200);
        });
        
        // Update active thumbnail
        $('.thumbnail-image').removeClass('active');
        $(this).addClass('active');
    });
    
    // Product description tabs
    $('.tab-link').on('click', function(e) {
        e.preventDefault();
        const target = $(this).data('target');
        
        // Update active tab
        $('.tab-link').removeClass('active');
        $(this).addClass('active');
        
        // Show target content
        $('.tab-content').removeClass('active');
        $(target).addClass('active');
    });
    
    // Related products carousel (if many products)
    if ($('.related-products-carousel').length) {
        $('.related-products-carousel').slick({
            dots: false,
            arrows: true,
            infinite: true,
            speed: 300,
            slidesToShow: 4,
            slidesToScroll: 1,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 2
                    }
                },
                {
                    breakpoint: 576,
                    settings: {
                        slidesToShow: 1
                    }
                }
            ]
        });
    }
});
