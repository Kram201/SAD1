$(document).ready(function () {
    // Handle category filter changes
    $('.category-filter input[type="radio"]').on('change', function() {
        applyFilters();
    });

    // Handle price range filter
    $('#apply-price').on('click', function() {
        applyFilters();
    });

    // Handle sorting
    $('#sort-products').on('change', function() {
        sortProducts($(this).val());
    });

    // Clear all filters
    $('#clear-filters').on('click', function() {
        // Reset category filter
        $('#all-categories').prop('checked', true);
        
        // Reset price filter
        $('#min-price').val('');
        $('#max-price').val('');
        
        // Reset sorting
        $('#sort-products').val('name-asc');
        
        // Apply filters (will show all products)
        applyFilters();
    });

    // Search form submission
    $('#search-form').on('submit', function(e) {
        e.preventDefault();
        
        const searchQuery = $('#search-input').val().toLowerCase();
        
        // Filter products based on search query
        $('.product-card-wrapper').each(function() {
            const productName = $(this).data('name').toLowerCase();
            
            if (productName.includes(searchQuery)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
        
        updateResultsCount();
    });

    // Function to apply all filters
    function applyFilters() {
        const selectedCategory = $('.category-filter input[type="radio"]:checked').val();
        const minPrice = $('#min-price').val() ? parseFloat($('#min-price').val()) : 0;
        const maxPrice = $('#max-price').val() ? parseFloat($('#max-price').val()) : Infinity;
        
        // Filter products
        $('.product-card-wrapper').each(function() {
            const productCategory = $(this).data('category').toString();
            const productPrice = parseFloat($(this).data('price'));
            
            // Check if product matches all filters
            const matchesCategory = selectedCategory === '' || productCategory === selectedCategory;
            const matchesPrice = productPrice >= minPrice && productPrice <= maxPrice;
            
            if (matchesCategory && matchesPrice) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
        
        // Update results count
        updateResultsCount();
        
        // Apply current sorting
        sortProducts($('#sort-products').val());
    }

    // Function to sort products
    function sortProducts(sortOption) {
        const $productsContainer = $('.product-grid');
        const $products = $('.product-card-wrapper:visible').detach();
        
        // Sort products based on selected option
        $products.sort(function(a, b) {
            const $a = $(a);
            const $b = $(b);
            
            switch (sortOption) {
                case 'name-asc':
                    return $a.data('name').localeCompare($b.data('name'));
                case 'name-desc':
                    return $b.data('name').localeCompare($a.data('name'));
                case 'price-asc':
                    return $a.data('price') - $b.data('price');
                case 'price-desc':
                    return $b.data('price') - $a.data('price');
                default:
                    return 0;
            }
        });
        
        // Append sorted products back to grid
        $productsContainer.append($products);
    }

    // Function to update results count
    function updateResultsCount() {
        const visibleProducts = $('.product-card-wrapper:visible').length;
        $('.results-count').text(`Showing ${visibleProducts} product(s)`);
        
        // Show "no products found" message if needed
        if (visibleProducts === 0) {
            if ($('.no-products-message').length === 0) {
                $('.product-grid').append(
                    '<div class="col-md-12 no-products-message">' +
                    '<div class="alert alert-info">' +
                    'No products found matching your criteria.' +
                    '</div></div>'
                );
            }
        } else {
            $('.no-products-message').remove();
        }
    }

    // Initialize with default sorting
    sortProducts('name-asc');
});
