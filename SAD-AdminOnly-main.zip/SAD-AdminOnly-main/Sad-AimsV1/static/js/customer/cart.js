$(document).ready(function () {
    // Quantity change handlers
    $('.btn-increase').on('click', function() {
        const input = $(this).siblings('.quantity-input');
        const currentValue = parseInt(input.val());
        const maxValue = parseInt(input.attr('max'));
        
        if (currentValue < maxValue) {
            input.val(currentValue + 1);
            updateCart(input);
        }
    });
    
    $('.btn-decrease').on('click', function() {
        const input = $(this).siblings('.quantity-input');
        const currentValue = parseInt(input.val());
        
        if (currentValue > 1) {
            input.val(currentValue - 1);
            updateCart(input);
        }
    });
    
    // Update cart on manual input change
    $('.quantity-input').on('change', function() {
        updateCart($(this));
    });
    
    // Function to submit the form when quantity is changed
    function updateCart(input) {
        input.closest('form').submit();
    }
    
    // Clear cart confirmation
    $('.clear-cart').on('click', function() {
        if (confirm('Are you sure you want to clear your cart?')) {
            // Redirect to clear cart endpoint
            window.location.href = '/customer/clear-cart';
        }
    });
    
    // Auto update price calculations
    function updatePrices() {
        let total = 0;
        
        $('.cart-item').each(function() {
            const price = parseFloat($(this).find('.price').text().replace('₱', '').trim());
            const quantity = parseInt($(this).find('.quantity-input').val());
            const subtotal = price * quantity;
            
            $(this).find('.subtotal').text('₱' + subtotal.toFixed(2));
            total += subtotal;
        });
        
        $('.cart-total').text('₱' + total.toFixed(2));
    }
    
    // Call updatePrices on page load and whenever quantity changes
    updatePrices();
    $('.quantity-input').on('change keyup', updatePrices);
    $('.btn-increase, .btn-decrease').on('click', updatePrices);
    
    // Animate price changes
    function animateValue(element, start, end, duration) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            const value = progress * (end - start) + start;
            element.text('₱' + value.toFixed(2));
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    }
});
