$(document).ready(function () {
    // Payment method selection
    $('input[name="payment_method"]').on('change', function() {
        // Hide all payment details sections
        $('.payment-details').addClass('d-none');
        
        const selectedMethod = $(this).val();
        
        // Show the appropriate payment details section
        if (selectedMethod === 'credit_card') {
            $('.credit-card-details').removeClass('d-none');
        } else if (selectedMethod === 'bank_transfer') {
            $('.bank-transfer-details').removeClass('d-none');
        }
    });
    
    // Form validation
    $('#checkout-form').on('submit', function(e) {
        const selectedMethod = $('input[name="payment_method"]:checked').val();
        
        if (selectedMethod === 'credit_card') {
            const cardNumber = $('#card_number').val().trim();
            const expiryDate = $('#expiry_date').val().trim();
            const cvv = $('#cvv').val().trim();
            
            if (!cardNumber || !expiryDate || !cvv) {
                e.preventDefault();
                alert('Please fill in all credit card details');
                return false;
            }
            
            // Basic credit card validation
            if (!validateCreditCard(cardNumber)) {
                e.preventDefault();
                alert('Please enter a valid credit card number');
                return false;
            }
        } else if (selectedMethod === 'bank_transfer') {
            if (!$('#confirm_transfer').is(':checked')) {
                e.preventDefault();
                alert('Please confirm that you will complete the bank transfer');
                return false;
            }
        }
    });
    
    // Basic credit card validation
    function validateCreditCard(cardNumber) {
        // Remove spaces and hyphens
        cardNumber = cardNumber.replace(/[\s-]/g, '');
        
        // Check if the card number is numeric and between 13-19 digits
        return /^\d{13,19}$/.test(cardNumber);
    }
    
    // Format credit card number as the user types
    $('#card_number').on('input', function() {
        let value = $(this).val().replace(/\D/g, '');
        let formattedValue = '';
        
        for (let i = 0; i < value.length; i++) {
            if (i > 0 && i % 4 === 0) {
                formattedValue += ' ';
            }
            formattedValue += value[i];
        }
        
        $(this).val(formattedValue);
    });
    
    // Format expiry date as MM/YY
    $('#expiry_date').on('input', function() {
        let value = $(this).val().replace(/\D/g, '');
        
        if (value.length > 2) {
            value = value.substring(0, 2) + '/' + value.substring(2, 4);
        }
        
        $(this).val(value);
    });
    
    // Limit CVV to 3 or 4 digits
    $('#cvv').on('input', function() {
        let value = $(this).val().replace(/\D/g, '');
        $(this).val(value.substring(0, 4));
    });
});
