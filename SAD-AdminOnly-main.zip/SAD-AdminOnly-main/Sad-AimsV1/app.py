from flask import Flask, render_template, request, redirect, url_for, flash, session
import os
import sys
from datetime import datetime

# Set up path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import route blueprints
from backend.routes.admin import admin_bp
from backend.routes.auths import auth_bp
from backend.routes.customer import customer_bp
from backend.routes.inventory import inventory_bp, register_inventory_routes

# Import database connection
from backend.database import get_db_connection

# Create Flask app
app = Flask(__name__)
app.secret_key = 'sad-aims-secret-key-2025'  # For session/flash messages

# Register blueprints
app.register_blueprint(admin_bp)
app.register_blueprint(auth_bp)
app.register_blueprint(customer_bp)
app.register_blueprint(inventory_bp)

# Register additional routes
register_inventory_routes(app)

# Configure upload folder
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Home route
@app.route('/')
def index():
    conn = get_db_connection()
    try:
        # Get featured products
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT p.*, c.name as category_name 
                FROM products p
                JOIN categories c ON p.category_id = c.id
                WHERE p.featured = 1 AND p.status = 1
                LIMIT 6
            """)
            featured_products = cursor.fetchall()
            
        # Get newest products
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT p.*, c.name as category_name 
                FROM products p
                JOIN categories c ON p.category_id = c.id
                WHERE p.status = 1
                ORDER BY p.created_at DESC
                LIMIT 8
            """)
            new_products = cursor.fetchall()
            
        return render_template('index.html', 
                             featured_products=featured_products,
                             new_products=new_products)
    except Exception as e:
        print(f"Error in index: {e}")
        return render_template('index.html', error=str(e))
    finally:
        conn.close()

# About route
@app.route('/about')
def about():
    return render_template('about.html')

# Contact route
@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        
        # Store in database
        conn = get_db_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO contact_messages 
                    (name, email, subject, message) 
                    VALUES (%s, %s, %s, %s)
                """, (name, email, subject, message))
            conn.commit()
            flash('Your message has been sent. Thank you!', 'success')
        except Exception as e:
            flash(f'There was an error sending your message: {str(e)}', 'error')
        finally:
            conn.close()
            
        return redirect(url_for('contact'))
        
    return render_template('contact.html')

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('errors/404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('errors/500.html'), 500

# Template filters
@app.template_filter('format_date')
def format_date(value, format='%B %d, %Y'):
    if value is None:
        return ""
    if isinstance(value, str):
        try:
            value = datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            return value
    return value.strftime(format)

@app.template_filter('format_currency')
def format_currency(value):
    if value is None:
        return "$0.00"
    return "${:,.2f}".format(float(value))

# Context processor for global template variables
@app.context_processor
def inject_globals():
    cart_count = 0
    if 'cart' in session:
        cart_count = sum(item['quantity'] for item in session['cart'])
    
    # Get settings
    settings = {}
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM settings")
            settings_rows = cursor.fetchall()
            settings = {item['setting_key']: item['setting_value'] for item in settings_rows}
    except Exception as e:
        print(f"Error loading settings: {e}")
    finally:
        conn.close()
    
    return {
        'cart_count': cart_count,
        'current_year': datetime.now().year,
        'settings': settings,
        'user': session.get('user_name', None),
        'user_role': session.get('role', None)
    }

# Run the app
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
